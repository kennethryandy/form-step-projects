const variables = {
  googleApiKey: "",
};

export default variables;
