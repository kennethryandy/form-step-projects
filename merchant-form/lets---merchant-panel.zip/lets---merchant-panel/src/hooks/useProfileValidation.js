import {useEffect, useState} from 'react'

const useProfileValidation = () => {
    const [errors, setErrors] = useState({})
    return (
        <div>
            
        </div>
    )
}

export default useProfileValidation
