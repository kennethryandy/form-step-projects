const phoneData = [
  { dataCountryCode: "AF", value: "93", name: "Afghanistan (+93)" },

  { dataCountryCode: "AL", value: "355", name: "Albania (+355)" },

  { dataCountryCode: "DZ", value: "213", name: "Algeria (+213)" },

  { dataCountryCode: "AS", value: "1684", name: "American Samoa (+1684)" },

  { dataCountryCode: "AD", value: "376", name: "Andorra (+376)" },

  { dataCountryCode: "AO", value: "244", name: "Angola (+244)" },

  { dataCountryCode: "AI", value: "1264", name: "Anguilla (+1264)" },

  { dataCountryCode: "AQ", value: "672", name: "Antartica (+672)" },

  {
    dataCountryCode: "AG",
    value: "1268",
    name: "Antigua &amp; Barbuda (+1268)",
  },

  { dataCountryCode: "AR", value: "54", name: "Argentina (+54)" },

  { dataCountryCode: "AM", value: "374", name: "Armenia (+374)" },

  { dataCountryCode: "AW", value: "297", name: "Aruba (+297)" },

  { dataCountryCode: "AU", value: "61", name: "Australia (+61)" },

  { dataCountryCode: "AT", value: "43", name: "Austria (+43)" },

  { dataCountryCode: "AZ", value: "994", name: "Azerbaijan (+994)" },

  { dataCountryCode: "BS", value: "1242", name: "Bahamas (+1242)" },

  { dataCountryCode: "BH", value: "973", name: "Bahrain (+973)" },

  { dataCountryCode: "BD", value: "880", name: "Bangladesh (+880)" },

  { dataCountryCode: "BB", value: "1246", name: "Barbados (+1246)" },

  { dataCountryCode: "BY", value: "375", name: "Belarus (+375)" },

  { dataCountryCode: "BE", value: "32", name: "Belgium (+32)" },

  { dataCountryCode: "BZ", value: "501", name: "Belize (+501)" },

  { dataCountryCode: "BJ", value: "229", name: "Benin (+229)" },

  { dataCountryCode: "BM", value: "1441", name: "Bermuda (+1441)" },

  { dataCountryCode: "BT", value: "975", name: "Bhutan (+975)" },

  { dataCountryCode: "BO", value: "591", name: "Bolivia (+591)" },

  {
    dataCountryCode: "BA",
    value: "387",
    name: "Bosnia &amp; Herzegovina (+387)",
  },

  { dataCountryCode: "BW", value: "267", name: "Botswana (+267)" },

  { dataCountryCode: "BR", value: "55", name: "Brazil (+55)" },

  {
    dataCountryCode: "IO",
    value: "246",
    name: "British India Ocean Terrirory (+246)",
  },

  {
    dataCountryCode: "VG",
    value: "1284",
    name: "British Virgin Islands (+1284)",
  },

  { dataCountryCode: "BN", value: "673", name: "Brunei (+673)" },

  { dataCountryCode: "BG", value: "359", name: "Bulgaria (+359)" },

  { dataCountryCode: "BF", value: "226", name: "Burkina Faso (+226)" },

  { dataCountryCode: "BI", value: "257", name: "Burundi (+257)" },

  { dataCountryCode: "KH", value: "855", name: "Cambodia (+855)" },

  { dataCountryCode: "CM", value: "237", name: "Cameroon (+237)" },

  { dataCountryCode: "CA", value: "1", name: "Canada (+1)" },

  { dataCountryCode: "CV", value: "238", name: "Cape Verde Islands (+238)" },

  { dataCountryCode: "KY", value: "1345", name: "Cayman Islands (+1345)" },

  {
    dataCountryCode: "CF",
    value: "236",
    name: "Central African Republic (+236)",
  },

  { dataCountryCode: "TD", value: "235", name: "Chad (+235)" },

  { dataCountryCode: "CL", value: "56", name: "Chile (+56)" },

  { dataCountryCode: "CN", value: "86", name: "China (+86)" },

  { dataCountryCode: "CX", value: "61", name: "Christmas Island (+61)" },

  { dataCountryCode: "CC", value: "61", name: "Cocos Islands (+61)" },

  { dataCountryCode: "CO", value: "57", name: "Colombia (+57)" },

  { dataCountryCode: "KM", value: "269", name: "Comoros (+269)" },

  { dataCountryCode: "CK", value: "682", name: "Cook Islands (+682)" },

  { dataCountryCode: "CR", value: "506", name: "Costa Rica (+506)" },

  { dataCountryCode: "HR", value: "385", name: "Croatia (+385)" },

  { dataCountryCode: "CU", value: "53", name: "Cuba (+53)" },

  { dataCountryCode: "CW", value: "599", name: "Curacao (+599)" },

  { dataCountryCode: "CY", value: "90", name: "Cyprus - North (+90)" },

  { dataCountryCode: "CY", value: "357", name: "Cyprus - South (+357)" },

  { dataCountryCode: "CZ", value: "420", name: "Czech Republic (+420)" },

  {
    dataCountryCode: "CD",
    value: "243",
    name: "Democratic Republic of Congo (+243)",
  },

  { dataCountryCode: "DK", value: "45", name: "Denmark (+45)" },

  { dataCountryCode: "DJ", value: "253", name: "Djibouti (+253)" },

  { dataCountryCode: "DM", value: "1809", name: "Dominica (+1809)" },

  { dataCountryCode: "DO", value: "1809", name: "Dominican Republic (+1809)" },

  { dataCountryCode: "TL", value: "670", name: "East Timor (+670)" },

  { dataCountryCode: "EC", value: "593", name: "Ecuador (+593)" },

  { dataCountryCode: "EG", value: "20", name: "Egypt (+20)" },

  { dataCountryCode: "SV", value: "503", name: "El Salvador (+503)" },

  { dataCountryCode: "GQ", value: "240", name: "Equatorial Guinea (+240)" },

  { dataCountryCode: "ER", value: "291", name: "Eritrea (+291)" },

  { dataCountryCode: "EE", value: "372", name: "Estonia (+372)" },

  { dataCountryCode: "ET", value: "251", name: "Ethiopia (+251)" },

  { dataCountryCode: "FK", value: "500", name: "Falkland Islands (+500)" },

  { dataCountryCode: "FO", value: "298", name: "Faroe Islands (+298)" },

  { dataCountryCode: "FJ", value: "679", name: "Fiji (+679)" },

  { dataCountryCode: "FI", value: "358", name: "Finland (+358)" },

  { dataCountryCode: "FR", value: "33", name: "France (+33)" },

  { dataCountryCode: "GF", value: "594", name: "French Guiana (+594)" },

  { dataCountryCode: "PF", value: "689", name: "French Polynesia (+689)" },

  { dataCountryCode: "GA", value: "241", name: "Gabon (+241)" },

  { dataCountryCode: "GM", value: "220", name: "Gambia (+220)" },

  { dataCountryCode: "GE", value: "7880", name: "Georgia (+7880)" },

  { dataCountryCode: "DE", value: "49", name: "Germany (+49)" },

  { dataCountryCode: "GH", value: "233", name: "Ghana (+233)" },

  { dataCountryCode: "GI", value: "350", name: "Gibraltar (+350)" },

  { dataCountryCode: "GR", value: "30", name: "Greece (+30)" },

  { dataCountryCode: "GL", value: "299", name: "Greenland (+299)" },

  { dataCountryCode: "GD", value: "1473", name: "Grenada (+1473)" },

  { dataCountryCode: "GP", value: "590", name: "Guadeloupe (+590)" },

  { dataCountryCode: "GU", value: "671", name: "Guam (+671)" },

  { dataCountryCode: "GT", value: "502", name: "Guatemala (+502)" },

  { dataCountryCode: "GG", value: "44", name: "Guernsey (+44)" },

  { dataCountryCode: "GN", value: "224", name: "Guinea (+224)" },

  { dataCountryCode: "GW", value: "245", name: "Guinea-Bissau (+245)" },

  { dataCountryCode: "GY", value: "592", name: "Guyana (+592)" },

  { dataCountryCode: "HT", value: "509", name: "Haiti (+509)" },

  { dataCountryCode: "HN", value: "504", name: "Honduras (+504)" },

  { dataCountryCode: "HK", value: "852", name: "Hong Kong (+852)" },

  { dataCountryCode: "HU", value: "36", name: "Hungary (+36)" },

  { dataCountryCode: "IS", value: "354", name: "Iceland (+354)" },

  { dataCountryCode: "IN", value: "91", name: "India (+91)" },

  { dataCountryCode: "ID", value: "62", name: "Indonesia (+62)" },

  { dataCountryCode: "IR", value: "98", name: "Iran (+98)" },

  { dataCountryCode: "IQ", value: "964", name: "Iraq (+964)" },

  { dataCountryCode: "IE", value: "353", name: "Ireland (+353)" },

  { dataCountryCode: "IM", value: "44", name: "Isle of Man (+44)" },

  { dataCountryCode: "IL", value: "972", name: "Israel (+972)" },

  { dataCountryCode: "IT", value: "39", name: "Italy (+39)" },

  { dataCountryCode: "CI", value: "225", name: "Ivory Coast (+225)" },

  { dataCountryCode: "JM", value: "1876", name: "Jamaica (+1876)" },

  { dataCountryCode: "JP", value: "81", name: "Japan (+81)" },

  { dataCountryCode: "JE", value: "44", name: "Jersey (+44)" },

  { dataCountryCode: "JO", value: "962", name: "Jordan (+962)" },

  { dataCountryCode: "KZ", value: "7", name: "Kazakhstan (+7)" },

  { dataCountryCode: "KE", value: "254", name: "Kenya (+254)" },

  { dataCountryCode: "KI", value: "686", name: "Kiribati (+686)" },

  { dataCountryCode: "XK", value: "383", name: "Kosovo (+383)" },

  { dataCountryCode: "KW", value: "965", name: "Kuwait (+965)" },

  { dataCountryCode: "KG", value: "996", name: "Kyrgyzstan (+996)" },

  { dataCountryCode: "LA", value: "856", name: "Laos (+856)" },

  { dataCountryCode: "LV", value: "371", name: "Latvia (+371)" },

  { dataCountryCode: "LB", value: "961", name: "Lebanon (+961)" },

  { dataCountryCode: "LS", value: "266", name: "Lesotho (+266)" },

  { dataCountryCode: "LR", value: "231", name: "Liberia (+231)" },

  { dataCountryCode: "LY", value: "218", name: "Libya (+218)" },

  { dataCountryCode: "LI", value: "417", name: "Liechtenstein (+417)" },

  { dataCountryCode: "LT", value: "370", name: "Lithuania (+370)" },

  { dataCountryCode: "LU", value: "352", name: "Luxembourg (+352)" },

  { dataCountryCode: "MO", value: "853", name: "Macao (+853)" },

  { dataCountryCode: "MK", value: "389", name: "Macedonia (+389)" },

  { dataCountryCode: "MG", value: "261", name: "Madagascar (+261)" },

  { dataCountryCode: "MW", value: "265", name: "Malawi (+265)" },

  { dataCountryCode: "MY", value: "60", name: "Malaysia (+60)" },

  { dataCountryCode: "MV", value: "960", name: "Maldives (+960)" },

  { dataCountryCode: "ML", value: "223", name: "Mali (+223)" },

  { dataCountryCode: "MT", value: "356", name: "Malta (+356)" },

  { dataCountryCode: "MH", value: "692", name: "Marshall Islands (+692)" },

  { dataCountryCode: "MQ", value: "596", name: "Martinique (+596)" },

  { dataCountryCode: "MR", value: "222", name: "Mauritania (+222)" },

  { dataCountryCode: "YT", value: "269", name: "Mayotte (+269)" },

  { dataCountryCode: "MX", value: "52", name: "Mexico (+52)" },

  { dataCountryCode: "FM", value: "691", name: "Micronesia (+691)" },

  { dataCountryCode: "MD", value: "373", name: "Moldova (+373)" },

  { dataCountryCode: "MC", value: "377", name: "Monaco (+377)" },

  { dataCountryCode: "MN", value: "976", name: "Mongolia (+976)" },

  { dataCountryCode: "ME", value: "382", name: "Montengro (+382)" },

  { dataCountryCode: "MS", value: "1664", name: "Montserrat (+1664)" },

  { dataCountryCode: "MA", value: "212", name: "Morocco (+212)" },

  { dataCountryCode: "MZ", value: "258", name: "Mozambique (+258)" },

  { dataCountryCode: "MN", value: "95", name: "Myanmar (+95)" },

  { dataCountryCode: "NA", value: "264", name: "Namibia (+264)" },

  { dataCountryCode: "NR", value: "674", name: "Nauru (+674)" },

  { dataCountryCode: "NP", value: "977", name: "Nepal (+977)" },

  { dataCountryCode: "NL", value: "31", name: "Netherlands (+31)" },

  { dataCountryCode: "AN", value: "599", name: "Netherlands Antilles (+599)" },

  { dataCountryCode: "NC", value: "687", name: "New Caledonia (+687)" },

  { dataCountryCode: "NZ", value: "64", name: "New Zealand (+64)" },

  { dataCountryCode: "NI", value: "505", name: "Nicaragua (+505)" },

  { dataCountryCode: "NE", value: "227", name: "Niger (+227)" },

  { dataCountryCode: "NG", value: "234", name: "Nigeria (+234)" },

  { dataCountryCode: "NU", value: "683", name: "Niue (+683)" },

  { dataCountryCode: "KP", value: "850", name: "North Korea (+850)" },

  { dataCountryCode: "NF", value: "672", name: "Norfolk Islands (+672)" },

  { dataCountryCode: "NP", value: "670", name: "Northern Marianas (+670)" },

  { dataCountryCode: "NO", value: "47", name: "Norway (+47)" },

  { dataCountryCode: "OM", value: "968", name: "Oman (+968)" },

  { dataCountryCode: "PK", value: "92", name: "Pakistan (+92)" },

  { dataCountryCode: "PW", value: "680", name: "Palau (+680)" },

  { dataCountryCode: "PS", value: "970", name: "Palestine (+970)" },

  { dataCountryCode: "PA", value: "507", name: "Panama (+507)" },

  { dataCountryCode: "PG", value: "675", name: "Papua New Guinea (+675)" },

  { dataCountryCode: "PY", value: "595", name: "Paraguay (+595)" },

  { dataCountryCode: "PE", value: "51", name: "Peru (+51)" },

  { dataCountryCode: "PH", value: "63", name: "Philippines (+63)" },

  { dataCountryCode: "PN", value: "64", name: "Pitcairn (+64)" },

  { dataCountryCode: "PL", value: "48", name: "Poland (+48)" },

  { dataCountryCode: "PT", value: "351", name: "Portugal (+351)" },

  { dataCountryCode: "PR", value: "1787", name: "Puerto Rico (+1787)" },

  { dataCountryCode: "QA", value: "974", name: "Qatar (+974)" },

  { dataCountryCode: "CG", value: "242", name: "Republic of the Congo (+242)" },

  { dataCountryCode: "RE", value: "262", name: "Reunion (+262)" },

  { dataCountryCode: "RO", value: "40", name: "Romania (+40)" },

  { dataCountryCode: "RU", value: "7", name: "Russia (+7)" },

  { dataCountryCode: "RW", value: "250", name: "Rwanda (+250)" },

  { dataCountryCode: "BL", value: "590", name: "Saint Barthelemy (+590)" },

  { dataCountryCode: "SH", value: "290", name: "Saint Helena (+290)" },

  {
    dataCountryCode: "KN",
    value: "1869",
    name: "Saint Kitts &amp; Nevis (+1869)",
  },

  { dataCountryCode: "SC", value: "1758", name: "Saint Lucia (+1758)" },

  { dataCountryCode: "SR", value: "597", name: "Suriname (+597)" },

  { dataCountryCode: "MF", value: "590", name: "Saint Martin (+590)" },

  {
    dataCountryCode: "PM",
    value: "508",
    name: "Saint Saint Pierre and Miquelon (+508)",
  },

  {
    dataCountryCode: "VC",
    value: "1784",
    name: "Saint Vincent and the Grenadines (+1784)",
  },

  { dataCountryCode: "WS", value: "685", name: "Samoa (+685)" },

  { dataCountryCode: "SM", value: "378", name: "San Marino (+378)" },

  {
    dataCountryCode: "ST",
    value: "239",
    name: "Sao Tome &amp; Principe (+239)",
  },

  { dataCountryCode: "SA", value: "966", name: "Saudi Arabia (+966)" },

  { dataCountryCode: "SN", value: "221", name: "Senegal (+221)" },

  { dataCountryCode: "CS", value: "381", name: "Serbia (+381)" },

  { dataCountryCode: "SC", value: "248", name: "Seychelles (+248)" },

  { dataCountryCode: "SL", value: "232", name: "Sierra Leone (+232)" },

  { dataCountryCode: "SG", value: "65", name: "Singapore (+65)" },

  { dataCountryCode: "SX", value: "1721", name: "Sint Maarten (+1721)" },

  { dataCountryCode: "SK", value: "421", name: "Slovakia (+421)" },

  { dataCountryCode: "SI", value: "386", name: "Slovenia (+386)" },

  { dataCountryCode: "SB", value: "677", name: "Solomon Islands (+677)" },

  { dataCountryCode: "SO", value: "252", name: "Somalia (+252)" },

  { dataCountryCode: "ZA", value: "27", name: "South Africa (+27)" },

  { dataCountryCode: "KR", value: "82", name: "South Korea (+82)" },

  { dataCountryCode: "SS", value: "211", name: "South Sudan (+211)" },

  { dataCountryCode: "ES", value: "34", name: "Spain (+34)" },

  { dataCountryCode: "LK", value: "94", name: "Sri Lanka (+94)" },

  { dataCountryCode: "SD", value: "249", name: "Sudan (+249)" },

  { dataCountryCode: "SR", value: "597", name: "Suriname (+597)" },

  {
    dataCountryCode: "SJ",
    value: "47",
    name: "Svalbard &amp; Jan Mayen (+47)",
  },

  { dataCountryCode: "SZ", value: "268", name: "Swaziland (+268)" },

  { dataCountryCode: "SE", value: "46", name: "Sweden (+46)" },

  { dataCountryCode: "CH", value: "41", name: "Switzerland (+41)" },

  { dataCountryCode: "SY", value: "963", name: "Syria (+963)" },

  { dataCountryCode: "TW", value: "886", name: "Taiwan (+886)" },

  { dataCountryCode: "TJ", value: "992", name: "Tajikistan (+992)" },

  { dataCountryCode: "TZ", value: "255", name: "Tanzania (+255)" },

  { dataCountryCode: "TH", value: "66", name: "Thailand (+66)" },

  { dataCountryCode: "TG", value: "228", name: "Togo (+228)" },

  { dataCountryCode: "TO", value: "676", name: "Tonga (+676)" },

  {
    dataCountryCode: "TT",
    value: "1868",
    name: "Trinidad &amp; Tobago (+1868)",
  },

  { dataCountryCode: "TN", value: "216", name: "Tunisia (+216)" },

  { dataCountryCode: "TR", value: "90", name: "Turkey (+90)" },

  { dataCountryCode: "TM", value: "993", name: "Turkmenistan (+993)" },

  {
    dataCountryCode: "TC",
    value: "1649",
    name: "Turks &amp; Caicos Islands (+1649)",
  },

  { dataCountryCode: "TV", value: "688", name: "Tuvalu (+688)" },

  { dataCountryCode: "UG", value: "256", name: "Uganda (+256)" },

  { dataCountryCode: "UA", value: "380", name: "Ukraine (+380)" },

  { dataCountryCode: "AE", value: "971", name: "United Arab Emirates (+971)" },

  { dataCountryCode: "GB", value: "44", name: "United Kingdom (+44)" },

  { dataCountryCode: "US", value: "1", name: "United States (+1)" },

  { dataCountryCode: "UY", value: "598", name: "Uruguay (+598)" },

  { dataCountryCode: "UZ", value: "998", name: "Uzbekistan (+998)" },

  { dataCountryCode: "VU", value: "678", name: "Vanuatu (+678)" },

  { dataCountryCode: "VA", value: "379", name: "Vatican City (+379)" },

  { dataCountryCode: "VE", value: "58", name: "Venezuela (+58)" },

  { dataCountryCode: "VN", value: "84", name: "Vietnam (+84)" },

  { dataCountryCode: "WF", value: "681", name: "Wallis &amp; Futuna (+681)" },

  { dataCountryCode: "YE", value: "969", name: "Yemen (North)(+969)" },

  { dataCountryCode: "YE", value: "967", name: "Yemen (South)(+967)" },

  { dataCountryCode: "ZM", value: "260", name: "Zambia (+260)" },

  { dataCountryCode: "ZW", value: "263", name: "Zimbabwe (+263)" },
];

export default phoneData;
