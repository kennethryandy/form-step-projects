import { useState } from "react";
import "./assets/css/style.css";
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect,
} from "react-router-dom";
//Material ui
import theme from "./config/muiTheme";
import { ThemeProvider } from "@material-ui/core/styles";
import CssBaseline from "@material-ui/core/CssBaseline";
import Container from "@material-ui/core/Container";
//Pages
import FormPage from "./pages/FormPage";
import SuccessPage from "./pages/SuccessPage";

function App() {
  const [isSuccess, setIsSuccess] = useState(false);

  return (
    <Router basename="/be-a-merchant">
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <Container maxWidth="lg">
          <Switch>
            <Route
              path="/"
              exact
              render={() => <FormPage setIsSuccess={setIsSuccess} />}
            />
            <Route
              path="/success"
              render={() => (isSuccess ? <SuccessPage /> : <Redirect to="/" />)}
            />
          </Switch>
        </Container>
      </ThemeProvider>
    </Router>
  );
}

export default App;
