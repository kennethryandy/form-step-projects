import React from "react";
const Img = (props) => {
  return <img alt={props.alt ? props.alt : ""} {...props} />;
};

export default Img;
