import { useEffect, useState, useCallback, useRef } from "react";
import { GoogleMap, Marker, useLoadScript } from "@react-google-maps/api";
import { getDetails } from "use-places-autocomplete";
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import Typography from "@material-ui/core/Typography";
import useStyles from "./mapStyles";
import SearchPlaces from "./SearchPlaces";
import vars from "../../config/variables";
import axios from "axios";
import MapModal from "./MapModal";

const mapContainerStyle = {
  width: "100%",
  height: "300px",
};
const options = {
  disableDefaultUI: true,
  zoomControl: true,
};
const url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=";
const libraries = ["places"];
function Map({ setInfos, errorLocation, setErrorLocation }) {
  const classes = useStyles();
  const [center, setCenter] = useState({
    lat: 14.676208,
    lng: 121.043861,
  });
  const [newValue, setNewValue] = useState("");
  const [isEstablishment, setIsEstablishment] = useState({
    open: false,
    preview_img: "",
    place_name: "",
  });
  const paperRef = useRef(null);
  const mapRef = useRef();
  const showPosition = useRef(() => {});
  const { isLoaded, loadError } = useLoadScript({
    googleMapsApiKey: vars.googleApiKey,
    libraries,
  });

  const onMapLoad = useCallback((map) => {
    mapRef.current = map;
  }, []);

  showPosition.current = (position) => {
    setInfos((prevState) => ({
      ...prevState,
      lat: position.coords.latitude,
      lng: position.coords.longitude,
    }));
    setCenter({
      lat: position.coords.latitude,
      lng: position.coords.longitude,
    });
  };

  useEffect(() => {
    if (errorLocation) {
      paperRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
    }
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition.current);
    } else {
      return;
    }
  }, [errorLocation]);

  const panTo = useCallback(({ lat, lng }) => {
    mapRef.current.panTo({ lat, lng });
    mapRef.current.setZoom(14);
  }, []);

  const onMapClick = useCallback(
    (e) => {
      if (e.placeId) {
        getDetails({ placeId: e.placeId })
          .then((details) => {
            setIsEstablishment({
              open: true,
              icon: details.icon,
              place_name: details.name,
              location: details.vicinity,
              details,
            });
          })
          .catch((err) => console.error(err));
      } else {
        axios
          .get(
            `${url}${e.latLng.lat()},${e.latLng.lng()}&key=${vars.googleApiKey}`
          )
          .then((res) => {
            if (res.data.status === "OK") {
              setInfos((prevState) => ({
                ...prevState,
                location_full_address: res.data.results[0].formatted_address,
                place_id: res.data.results[0].place_id,
              }));
              setNewValue(res.data.results[0].formatted_address);
            }
          })
          .catch((err) => console.error(err));
      }
      setCenter({
        lat: e.latLng.lat(),
        lng: e.latLng.lng(),
      });
      setInfos((prevState) => ({
        ...prevState,
        lat: e.latLng.lat(),
        lng: e.latLng.lng(),
      }));
    },
    [setInfos, setIsEstablishment]
  );

  const handleDragEnd = useCallback((e) => {
    axios
      .get(`${url}${e.latLng.lat()},${e.latLng.lng()}&key=${vars.googleApiKey}`)
      .then((res) => {
        if (res.data.status === "OK") {
          setInfos((prevState) => ({
            ...prevState,
            place_id: res.data.results[0].place_id,
            location_full_address: res.data.results[0].formatted_address,
            lat: e.latLng.lat(),
            lng: e.latLng.lng(),
          }));
          getDetails({
            placeId: res.data.results[0].place_id,
          }).then((details) => {
            if (details.types.includes("establishment")) {
              setIsEstablishment({
                open: true,
                icon: details.icon,
                place_name: details.name,
                location: details.vicinity,
                details,
              });
            }
          });
          setNewValue(res.data.results[0].formatted_address);
        }
      })
      .catch((err) => console.error(err));
    setCenter({
      lat: e.latLng.lat(),
      lng: e.latLng.lng(),
    });
    // eslint-disable-next-line
  }, []);

  if (loadError) return "Error";
  if (!isLoaded) return "Loading...";

  return (
    <Badge
      color="primary"
      badgeContent="1"
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper
        ref={paperRef}
        className={classes.paperRoot}
        elevation={3}
        style={{ border: errorLocation ? "1px solid red" : "" }}
      >
        <label className={classes.label}>
          Store Location Address<span>*</span>
        </label>
        <SearchPlaces
          center={center}
          panTo={panTo}
          setInfos={setInfos}
          setErrorLocation={setErrorLocation}
          setCenter={setCenter}
          newValue={newValue}
        />
        <GoogleMap
          mapContainerStyle={mapContainerStyle}
          zoom={16}
          center={center}
          onLoad={onMapLoad}
          options={options}
          onClick={onMapClick}
        >
          <Marker
            draggable={true}
            position={{ lat: center.lat, lng: center.lng }}
            onDragEnd={handleDragEnd}
          />
        </GoogleMap>
        <Typography variant="body2" color="error">
          {errorLocation}
        </Typography>
        <MapModal
          isEstablishment={isEstablishment}
          setIsEstablishment={setIsEstablishment}
          setNewValue={setNewValue}
          setInfos={setInfos}
        />
      </Paper>
    </Badge>
  );
}

export default Map;
