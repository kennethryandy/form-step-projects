import { useEffect, useRef } from "react";
import PinIcon from "@material-ui/icons/Room";
import useStyles from "./mapStyles";
import usePlacesAutocomplete, {
  getGeocode,
  getLatLng,
} from "use-places-autocomplete";
import "@reach/combobox/styles.css";
import {
  Combobox,
  ComboboxInput,
  ComboboxPopover,
  ComboboxList,
  ComboboxOption,
} from "@reach/combobox";

function SearchPlaces({
  panTo,
  center,
  setInfos,
  setErrorLocation,
  setCenter,
  newValue,
}) {
  const classes = useStyles();
  const searchInputRef = useRef();
  const {
    ready,
    value,
    suggestions: { status, data },
    setValue,
    clearSuggestions,
  } = usePlacesAutocomplete({
    debounce: 600,
    requestOptions: {
      location: { lat: () => center.lat, lng: () => center.lng },
      radius: 250 * 1000,
    },
  });

  useEffect(() => {
    if (newValue) {
      setValue(newValue);
      setInfos((prevState) => ({
        ...prevState,
        location_full_address: newValue,
      }));
      searchInputRef.current.focus();
    }
  }, [newValue, setValue, setInfos]);

  const handleInput = (e) => {
    setErrorLocation("");
    setValue(e.target.value);
    setInfos((prevState) => ({
      ...prevState,
      location_full_address: e.target.value,
    }));
  };

  const handleSelect = async (address) => {
    setErrorLocation("");
    setValue(address, false);
    setInfos((prevState) => ({
      ...prevState,
      location_full_address: address,
    }));
    clearSuggestions();

    try {
      const results = await getGeocode({ address });
      const { lat, lng } = await getLatLng(results[0]);
      setCenter({ lat, lng });
      setInfos((prevState) => ({
        ...prevState,
        lat,
        lng,
        place_id: results[0].place_id ? results[0].place_id : "",
      }));
      panTo({ lat, lng });
    } catch (error) {
      console.error("Error: ", error);
    }
  };

  return (
    <div className="search">
      <Combobox onSelect={handleSelect}>
        <ComboboxInput
          value={value}
          onChange={handleInput}
          disabled={!ready}
          placeholder="Search your location"
          className="form-control"
          name="location_full_address"
          ref={searchInputRef}
        />
        <ComboboxPopover>
          <ComboboxList>
            {status === "OK" &&
              data.map(({ description }, i) => {
                return (
                  <div key={i} className={classes.googleSearch}>
                    <PinIcon color="primary" fontSize="small" />
                    <ComboboxOption value={description} />
                  </div>
                );
              })}
          </ComboboxList>
        </ComboboxPopover>
      </Combobox>
    </div>
  );
}

export default SearchPlaces;
