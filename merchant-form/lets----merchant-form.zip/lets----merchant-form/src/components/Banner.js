import { lazy, Suspense } from "react";
import bannerSd from "../assets/images/banner_sd.jpg";
import bannerImg from "../assets/images/banner.png";
//Material ui
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import CheckCircleIcon from "@material-ui/icons/CheckCircle";
import { makeStyles } from "@material-ui/core/styles";
const Img = lazy(() => import("./Image/Img"));
const useStyles = makeStyles((theme) => ({
  girdContainer: {
    [theme.breakpoints.up("sm")]: {
      margin: `${theme.spacing(5) * 1.2}px 0px ${theme.spacing(5) * 2}px 0px`,
    },
    [theme.breakpoints.only("xs")]: {
      padding: 0,
    },
  },
  bannerText: {
    maxWidth: 460,
    textAlign: "justify",
    [theme.breakpoints.down("sm")]: {
      margin: "24px 0px",
    },
    "& p": { fontSize: "1.2rem" },
  },
  title: {
    margin: 0,
    padding: 0,
    fontWeight: "normal",
    display: "inline-block",
    [theme.breakpoints.only("sm")]: { width: "80%" },
    [theme.breakpoints.only("xs")]: {
      width: 210,
      fontSize: "2.6rem",
      marginLeft: theme.spacing(2),
    },
  },
  lets: {
    padding: 0,
    fontWeight: "bold",
    display: "inline-block",
    color: "#F4444F",
  },
  rootListIcon: {
    minWidth: 46,
    "& svg": { fontSize: "1.8rem" },
  },
  banner: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: `${theme.spacing(5)}px 0px`,
    [theme.breakpoints.only("xs")]: { margin: 0 },
  },
  bannerWrapper: {
    width: "100%",
    height: "100%",
    position: "relative",
    display: "flex",
    alignItems: "center",
    maxHeight: 360,
    "& img": {
      width: "100%",
      height: "auto",
    },
  },
  list: {
    "& svg": { [theme.breakpoints.only("xs")]: { fontSize: 24 } },
    "& p": { [theme.breakpoints.only("xs")]: { fontSize: "1rem" } },
  },
}));

function Banner() {
  const classes = useStyles();
  return (
    <Grid container className={classes.girdContainer} spacing={2}>
      <Grid item sm={6} className={classes.girdContainer}>
        <div className={classes.bannerText}>
          <Typography gutterBottom variant="h1" className={classes.title}>
            {" "}
            Be a <span className={classes.lets}>LETS</span> Merchant
          </Typography>
          <List className={classes.list}>
            <ListItem>
              <ListItemIcon classes={{ root: classes.rootListIcon }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Typography variant="body1" color="textSecondary">
                    Fast & Convenient
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemIcon classes={{ root: classes.rootListIcon }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Typography variant="body1" color="textSecondary">
                    No Hassle, Easy Inventory Tracking
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemIcon classes={{ root: classes.rootListIcon }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Typography variant="body1" color="textSecondary">
                    More Customers to Reach
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemIcon classes={{ root: classes.rootListIcon }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Typography variant="body1" color="textSecondary">
                    Highlight your Store on the Map
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemIcon classes={{ root: classes.rootListIcon }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Typography variant="body1" color="textSecondary">
                    Manage your funds wisely
                  </Typography>
                }
              />
            </ListItem>
            <ListItem>
              <ListItemIcon classes={{ root: classes.rootListIcon }}>
                <CheckCircleIcon color="primary" />
              </ListItemIcon>
              <ListItemText
                primary={
                  <Typography variant="body1" color="textSecondary">
                    Update your Product List that is visible to the customer
                    right away
                  </Typography>
                }
              />
            </ListItem>
          </List>
        </div>
      </Grid>
      <Grid item sm={6} className={classes.banner}>
        <div className={classes.bannerWrapper}>
          <Suspense fallback={<img src={bannerSd} alt="" width="500" />}>
            <Img src={bannerImg} alt="" />
          </Suspense>
        </div>
      </Grid>
    </Grid>
  );
}

export default Banner;
