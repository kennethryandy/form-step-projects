import { useEffect, useState, useRef } from "react";
import FlipMove from "react-flip-move";
//Material Ui
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import Typography from "@material-ui/core/Typography";
import Chip from "@material-ui/core/Chip";
import Button from "@material-ui/core/Button";
import Tooltip from "@material-ui/core/Tooltip";

import useStyles from "./selectStyles";

function SelectForm({ infos, setInfos, errorCategory, setErrorCategory }) {
  const classes = useStyles();
  const [options, setOptions] = useState([
    { item: "Automotive", created_at: "2020-12-08T22:37:07.643Z", default: true },
    { item: "Baby & Todler", created_at: "2020-12-08T22:37:21.887Z", default: true },
    { item: "Clothing & Shoes", created_at: "2020-12-08T22:37:32.959Z", default: true },
    { item: "Computers", created_at: "2020-12-08T22:37:43.632Z", default: true },
    { item: "Electronics", created_at: "2020-12-08T22:37:47.975Z", default: true },
    { item: "Health & Beauty", created_at: "2020-12-08T22:37:57.440Z", default: true },
    { item: "Women's Fashion", created_at: "2020-12-08T22:38:00.856Z", default: true },
    { item: "Men's Fashion", created_at: "2020-12-08T22:38:05.960Z", default: true },
    { item: "Others", created_at: "2020-12-08T22:38:09.946Z", default: true },
  ]);
  const [categoryInput, setCategoryInput] = useState("");
  const paperRef = useRef();

  useEffect(() => {
    if (errorCategory) {
      paperRef.current.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
    }
  }, [errorCategory]);

  const handleSelectItem = (item) => {
    setInfos((prevState) => ({
      ...prevState,
      category: item,
    }));
    if (errorCategory) {
      setErrorCategory("");
    }
  };

  const handleDeselectItem = (item) => {
    setInfos((prevState) => ({
      ...prevState,
      category: "",
    }));
  };

  const handleChange = (e) => {
    setCategoryInput(e.target.value);
  };

  const handleSubmitItem = () => {
    if (categoryInput.trim()) {
      const isExist = options.find(option => option.item.trim() === categoryInput.trim())
      if(isExist){
        setInfos((prevState) => ({
          ...prevState,
          category: categoryInput,
        }));
      }else {
        setOptions((prevState) => [
          { item: categoryInput, created_at: new Date().toISOString(), default: false },
          ...prevState,
        ]);
        setInfos((prevState) => ({
          ...prevState,
          category: categoryInput,
        }));
      }
      setCategoryInput("");
    }else {
      return
    }
  };

  const handleRemoveItem = (item) => {
    if (item.item === infos.category) {
      setInfos((prevState) => ({
        ...prevState,
        category: "",
      }));
    }
    const newItems = options.filter(
      (option) => option.created_at !== item.created_at
    );
    setOptions(newItems);
  };

  const handleKeyDown = (evt) => {
    if (evt.key === "Enter") {
      handleSubmitItem();
      evt.preventDefault();
    }
  };

  return (
    <Badge
      color="primary"
      badgeContent="5"
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper
        elevation={3}
        className={classes.paperRoot}
        style={{ border: errorCategory ? "1px solid red" : "" }}
        ref={paperRef}
      >
        <label className={classes.label}>
          Store Category
          <span>*</span>
        </label>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "cneter",
          }}
        >
          <input
            onChange={handleChange}
            placeholder="Store Category"
            className="form-control"
            style={{ flex: "2.5" }}
            onKeyDown={handleKeyDown}
            value={categoryInput}
          />
          <Button
            color="secondary"
            size="large"
            variant="contained"
            onClick={handleSubmitItem}
            className={classes.selectBtn}
          >
            Add
          </Button>
        </div>
        <div className={classes.chipsContainer}>
          <FlipMove>
            {options.map((option) => (
              <Tooltip
                title={option.item}
                placement="top"
                key={option.created_at}
              >
                {infos?.category === option.item ? (
                  <Chip
                    label={option.item}
                    clickable
                    onClick={ () => handleDeselectItem(option.item)}
                    onDelete={option.default ? null : () => handleRemoveItem(option)}
                    style={{ backgroundColor: "#FFC001" }}
                    classes={{ root: classes.chipRoot }}
                  />
                ) : (
                  <Chip
                    label={option.item}
                    clickable
                    onDelete={option.default ? null : () => handleRemoveItem(option)}
                    onClick={() => handleSelectItem(option.item)}
                    classes={{ root: classes.chipRoot }}
                  />
                )}
              </Tooltip>
            ))}
          </FlipMove>
        </div>

        <Typography variant="body2" color="error" style={{ margin: 8 }}>
          {errorCategory}
        </Typography>
      </Paper>
    </Badge>
  );
}

export default SelectForm;
