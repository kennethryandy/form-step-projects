import { makeStyles } from "@material-ui/core/styles";

export default makeStyles((theme) => ({
  ...theme.customStyles,
  label: {
    ...theme.customStyles.label,
    "& span": {
      marginLeft: 6,
      color: theme.palette.primary.main,
    },
  },
  anchorOriginTopLeftRectangle: {
    top: 30,
  },
  badge: {
    height: 36,
    width: 36,
    borderRadius: 18,
    border: "3px solid #fff",
  },
  badgeRoot: {
    display: "block",
    margin: `20px 15px`,
  },
  chipRoot: {
    margin: theme.spacing(1),
    fontSize: "1rem",
    height: 46,
    borderRadius: 12,
    width: 160,
    "& svg": {
      marginLeft: "auto",
    },
    [theme.breakpoints.only("xs")]: {
      width: "40%",
      height: 38,
      fontSize: ".8rem",
    },
  },
  chipsContainer: {
    display: "flex",
    flexWrap: "wrap",
    "& > div": {
      margin: theme.spacing(1),
      [theme.breakpoints.only("xs")]: { margin: 0 },
    },
  },
  selectBtn: {
    flex: ".6",
    padding: "12px 22px",
    marginLeft: theme.spacing(3),
    borderRadius: 10,
    color: "#FFF",
    [theme.breakpoints.only("xs")]: {
      marginLeft: theme.spacing(1),
      padding: "8px 22px",
    },
  },
}));
