import { makeStyles } from "@material-ui/core/styles";

export default makeStyles((theme) => ({
  ...theme.customStyles,
  label: {
    ...theme.customStyles.label,
    "& span": {
      marginLeft: 6,
      color: theme.palette.primary.main,
    },
  },
  anchorOriginTopLeftRectangle: {
    top: 30,
  },
  badge: {
    height: 36,
    width: 36,
    borderRadius: 18,
    border: "3px solid #fff",
  },
  badgeRoot: {
    display: "block",
    margin: `20px 15px`,
  },
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: "#fff",
  },
}));
