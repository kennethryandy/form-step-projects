import { useEffect, useRef, useState } from "react";
import { useField } from "formik";
//Material ui
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import Typography from "@material-ui/core/Typography";
import Backdrop from "@material-ui/core/Backdrop";
import CircularProgress from "@material-ui/core/CircularProgress";
import useStyles from "./inputStyle";
import { validateCred } from "../../../api";

function InputForm({
  type,
  num,
  text,
  placeholder,
  infos,
  isValidEmail,
  setIsValidEmail,
  ...props
}) {
  const classes = useStyles();
  const [field, meta, helpers] = useField(props);
  const [open, setOpen] = useState(false);
  const [emailError, setEmailError] = useState("")
  const errorText = meta.error && meta.touched ? meta.error : "";

  const paperRef = useRef(null);

  useEffect(() => {
    if (errorText) {
      paperRef.current.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
    }
  }, [errorText]);

  useEffect(() => {
    if (field.name === "store_name" && infos.store_name) {
      helpers.setValue(infos.store_name);
    } else if (field.name === "landline_number" && infos.landline_number) {
      helpers.setValue(infos.landline_number);
    }
    //eslint-disable-next-line
  }, [infos?.store_name, infos?.landline_number]);

  const handleFocus = (e) => {
    if (text === "Landline Number") {
      let newValue = e.target.value.replace(/[^0-9]+/g, "");
      helpers.setValue(newValue);
    }
  };

  const handleKeyDown = (e) => {
    if (text === "Landline Number") {
      if (e.target.value.length > 9 && e.keyCode !== 8) {
        e.preventDefault();
      }
      if (
        e.target.value.length > 10 &&
        e.keyCode > 31 &&
        (e.keyCode < 48 || e.keyCode > 57) &&
        (e.keyCode < 96 || e.keyCode > 105)
      ) {
        e.preventDefault();
      }
    }
  };
  const handleBlur = (e) => {
    const regex = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    if (
      text === "Email Address" &&
      regex.test(e.target.value) &&
      !emailError
    ) {
      setOpen(true);
      validateCred({ username: "", email: e.target.value }).then((res) => {
        if (!res.data?.success) {
          setEmailError("Email is already taken.");
        } else {
          setIsValidEmail(true);
        }
        setOpen(false);
      });
    } else if (text === "Landline Number") {
      let newValue = e.target.value.replace(/[^0-9]+/g, "");
      let origValue = e.target.value.replace(/[^0-9]+/g, "");
      if (newValue.length > 3) {
        newValue =
          newValue.slice(0, 3) +
          "-" +
          newValue.slice(3, 6) +
          "-" +
          newValue.slice(6);
      }
      if (origValue.length > 10) {
        helpers.setError("Landline number must at least be 10 digits long.");
      }
      helpers.setValue(newValue);
    }
    field.onBlur(e);
  };
  const handleChange = (e) => {
    if (text === "Email Address") {
      setIsValidEmail(false);
      setEmailError("")
    }
    field.onChange(e);
  };
  return (
    <Badge
      color="primary"
      badgeContent={num}
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper
        ref={paperRef}
        elevation={3}
        className={classes.paperRoot}
        style={{
          border: errorText || emailError ? "1px solid red" : "",
          padding: num === "3" ? "46px 24px" : "32px 24px",
        }}
      >
        <div className="file-upload">
          <label className={classes.label}>
            {text}
            {text !== "Landline Number" && <span>*</span>}
          </label>
          <input
            {...field}
            onChange={handleChange}
            className="form-control"
            type={type ? type : "text"}
            placeholder={placeholder}
            onKeyDown={handleKeyDown}
            onBlur={handleBlur}
            onFocus={handleFocus}
          />
          <Typography variant="body2" color="error">
            {errorText.includes("landline_number must be a `number`")
              ? "Invalid landline number"
              : errorText}
          </Typography>
          <Typography variant="body2" color="error">
            {emailError}
          </Typography>
        </div>
      </Paper>
      <Backdrop className={classes.backdrop} open={open}>
        <CircularProgress color="inherit" />
      </Backdrop>
    </Badge>
  );
}

export default InputForm;
