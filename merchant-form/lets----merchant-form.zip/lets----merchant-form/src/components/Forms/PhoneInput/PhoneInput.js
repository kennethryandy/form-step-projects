import { useEffect, useRef } from "react";
import phLogo from "../../../assets/icons/ph.webp";
import { useField } from "formik";
//Material Ui
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import Typography from "@material-ui/core/Typography";
import useStyles from "./phoneStyle";

function PhoneInput({ infos, ...props }) {
  const [field, meta, helpers] = useField(props);
  const errorText = meta.error && meta.touched ? meta.error : "";
  const classes = useStyles();
  const paperRef = useRef(null);
  useEffect(() => {
    if (errorText) {
      paperRef.current.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
    }
  }, [errorText]);

  useEffect(() => {
    const phone_number = infos.phone_number;
    if (infos?.phone_number.startsWith("+")) {
      const formattedNumber = phone_number.substring(3);
      helpers.setValue(formattedNumber);
    } else {
      helpers.setValue(phone_number);
    }
    //eslint-disable-next-line
  }, [infos?.phone_number]);

  const handleFocus = (e) => {
    let newValue = e.target.value.replace(/[^0-9]+/g, "");
    helpers.setValue(newValue);
  };

  const handleKeyDown = (e) => {
    if (e.target.value.length > 9 && e.keyCode !== 8) {
      e.preventDefault();
    }
    if (
      e.target.value.length > 10 &&
      e.keyCode > 31 &&
      (e.keyCode < 48 || e.keyCode > 57) &&
      (e.keyCode < 96 || e.keyCode > 105)
    ) {
      e.preventDefault();
    }
  };

  const handleBlur = (e) => {
    let newValue = e.target.value.replace(/[^0-9]+/g, "");
    let origValue = e.target.value.replace(/[^0-9]+/g, "");
    if (newValue.length > 3) {
      newValue =
        newValue.slice(0, 3) +
        "-" +
        newValue.slice(3, 6) +
        "-" +
        newValue.slice(6);
    }
    if (origValue.length > 10) {
      helpers.setError("Phone number must at least be 10 digits long.");
    }
    helpers.setValue(newValue);
    helpers.setValue(newValue);
    field.onBlur(e);
  };

  return (
    <Badge
      color="primary"
      badgeContent="7"
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper
        ref={paperRef}
        elevation={3}
        className={classes.paperRoot}
        style={{ border: errorText ? "1px solid red" : "" }}
      >
        <label className={classes.label}>
          Phone Number<span>*</span>
        </label>
        <div className={classes.alignCenter}>
          <div className={classes.countrySelectContainer}>
            <div className={classes.alignCenter}>
              <img src={phLogo} alt="" />
              <Typography variant="body1" style={{ marginRight: 8 }}>
                +63
              </Typography>
            </div>
            <input
              {...field}
              onKeyDown={handleKeyDown}
              onBlur={handleBlur}
              onFocus={handleFocus}
              className="form-control"
              placeholder="9 6523 12112"
            />
          </div>
        </div>
        <Typography variant="body2" color="error">
          {errorText.includes("phone_number must be a `number`")
            ? "Invalid phone number"
            : errorText}
        </Typography>
      </Paper>
    </Badge>
  );
}

export default PhoneInput;
