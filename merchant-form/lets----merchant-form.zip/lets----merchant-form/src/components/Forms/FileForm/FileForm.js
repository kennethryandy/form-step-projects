import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import uploadIcon from "../../../assets/icons/upload_file.svg";
import { truncate } from "../../../helpers/trunacateString";
import { uploadLogo } from "../../../api";
//Material ui
import Box from "@material-ui/core/Box";
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import Typography from "@material-ui/core/Typography";
import LinearProgress from "@material-ui/core/LinearProgress";
import IconButton from "@material-ui/core/IconButton";
import useStyles from "./fileStyle";
//Mui icons
import CloseIcon from "@material-ui/icons/Close";
function FileForm({ setInfos }) {
  const classes = useStyles();
  const [file, setFile] = useState(null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState('')

  const onDrop = useCallback(
    async (acceptedFiles,rejectedFiles) => {
      if(rejectedFiles.length > 0) {
        if(rejectedFiles[0].errors[0].code === "file-invalid-type"){
          return setError("Upload valid images. Only PNG and JPEG are allowed.")
        }else if(rejectedFiles[0].errors[0].code === "file-too-large"){
          return setError("The file is too large. Allowed limit is 5 MB.")
        }else if(rejectedFiles[0].errors[0].code ==="too-many-files"){
          return setError(rejectedFiles[0].errors[0].message)
        }else {
          return setError(rejectedFiles[0].errors[0].message)
        }
      }else if (acceptedFiles.length > 0) {
        if(error){
          setError("")
        }
        setProgress(0);
        setFile({
          preview: URL.createObjectURL(acceptedFiles[0]),
          file: acceptedFiles[0],
        });

        const formData = new FormData();
        formData.append("file", acceptedFiles[0], acceptedFiles[0].name);
        const res = await uploadLogo(formData, setProgress)
        if (!res.data.error){
          setInfos(prevState => ({
            ...prevState,
            store_logo_file_id: res.data.file_id,
          }))
          setProgress(100)
        }
      }
      return;
    },
    [error, setInfos]
  );

  const handleRemovePreview = () => {
    setFile(null);
    setInfos(prevState => ({
      ...prevState,
      store_logo_file_id: null
    }))
  };

  const {getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: "image/png,image/jpeg",
    onDrop,
    maxFiles: 1,
    maxSize: 5 * 1000000
  });
  return (
    <Badge
      color="primary"
      badgeContent="2"
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper elevation={3} className={classes.paperRoot} style={{ border: error ? "1px solid red" : "" }}>
        <div className={classes.formGroup}>
          <div>
            <div {...getRootProps()} className={classes.dragDropContainer}>
              <input {...getInputProps()} />
              <div>
                {file ? (
                  <img
                    src={file.preview}
                    alt="store logo"
                    style={{
                      opacity: isDragActive || progress !== 100 ? ".5" : 1,
                    }}
                  />
                ) : (
                  <img
                    src={uploadIcon}
                    alt=""
                    style={{
                      opacity: isDragActive ? ".5" : 1,
                    }}
                  />
                )}
              </div>
            </div>
          </div>
          <div className={classes.fileFormTitle}>
            <label htmlFor="file-input" className={classes.label}>
              Upload Business Logo{" "}
              <Typography
                variant="body2"
                color="textSecondary"
                display="inline"
              >
                (Optional)
              </Typography>
            </label>
            <Typography
              variant="body2"
              color="textSecondary"
              style={{ marginTop: 8 }}
            >
              Drag and drop to upload.
            </Typography>
            {file &&
              (progress === 100 ? (
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <Typography variant="body2" style={{ color: "#4BA4FF" }}>
                    {truncate(file.file.name, 20)}
                  </Typography>
                  <IconButton
                    style={{ marginLeft: 8 }}
                    size="small"
                    color="primary"
                    onClick={handleRemovePreview}
                  >
                    <CloseIcon fontSize="small" />
                  </IconButton>
                </div>
              ) : (
                <LinearProgressWithLabel
                  value={progress}
                  classes={{
                    root: classes.linearRoot,
                    bar: classes.bar,
                    colorPrimary: classes.linearProgressBg,
                  }}
                />
              ))}
          </div>
        </div>
        <Typography variant="body2" color="error">
          {error}
        </Typography>
      </Paper>
    </Badge>
  );
}

function LinearProgressWithLabel(props) {
  return (
    <Box display="flex" alignItems="center">
      <Box width="100%" mr={1}>
        <LinearProgress variant="determinate" {...props} />
      </Box>
      <Box minWidth={35}>
        <Typography variant="body2" color="textSecondary">{`${Math.round(
          props.value
        )}%`}</Typography>
      </Box>
    </Box>
  );
}

export default FileForm;
