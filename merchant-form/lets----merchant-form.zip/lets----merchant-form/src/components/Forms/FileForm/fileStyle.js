import { makeStyles } from "@material-ui/core/styles";

export default makeStyles((theme) => ({
  ...theme.customStyles,
  label: {
    ...theme.customStyles.label,
    "& span": {
      marginLeft: 6,
      color: theme.palette.primary.main,
    },
  },
  anchorOriginTopLeftRectangle: {
    top: 30,
  },
  badge: {
    height: 36,
    width: 36,
    borderRadius: 18,
    border: "3px solid #fff",
  },
  badgeRoot: {
    display: "block",
    margin: `20px 15px`,
  },
  formGroup: {
    display: "flex",
    alignItems: "center",
    "& img": {
      width: 128,
      minWidth: 128,
      maxHeight: 128,
      minHeight: 128,
      borderRadius: 10,
      border: "1.6px solid #DFE8F1",
      cursor: "pointer",
      [theme.breakpoints.only("xs")]: {
        width: 60,
        minWidth: 60,
        maxHeight: 60,
        minHeight: 60,
      },
    },
  },
  fileFormTitle: {
    marginLeft: theme.spacing(3),
    [theme.breakpoints.only("xs")]: { marginLeft: theme.spacing(1) },
  },
  dragDropContainer: {
    outline: "none",
    "& img:hover": {
      transition: `all 200ms ${theme.transitions.easing.easeInOut}`,
      transform: "scale(1.04)",
    },
  },
}));
