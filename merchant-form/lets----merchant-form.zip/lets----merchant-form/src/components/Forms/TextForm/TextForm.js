//Material ui
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import TextareaAutosize from "@material-ui/core/TextareaAutosize";
import Typography from "@material-ui/core/Typography";
import useStyles from "./textStyles";
import { useField } from "formik";

function TextForm({ text, ...props }) {
  const classes = useStyles();
  const [field, meta] = useField(props);
  const errorText = meta.error && meta.touched ? meta.error : "";
  return (
    <Badge
      color="primary"
      badgeContent="9"
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper
        elevation={3}
        className={classes.paperRoot}
        style={{ border: errorText ? "1px solid red" : "" }}
      >
        <label className={classes.label}>
          {text}{" "}
          <Typography variant="body2" color="textSecondary" display="inline">
            (Optional)
          </Typography>
        </label>
        <TextareaAutosize
          {...field}
          rows={4}
          rowsMax={6}
          className="form-control"
          style={{ fontSize: "1.1rem" }}
          placeholder="Type your store description here..."
        />
        <div className={classes.textCount}>
          <Typography
            variant="caption"
            color={errorText ? "error" : "textSecondary"}
            component="p"
          >
            {field.value ? field.value.length : 0}
            /255
          </Typography>
        </div>
        <Typography variant="body2" color="error">
          {errorText.includes("landline_number must be a `number`")
            ? "Invalid landline number"
            : errorText}
        </Typography>
      </Paper>
    </Badge>
  );
}

export default TextForm;
