// import { makeStyles } from "@material-ui/core/styles";

// export default makeStyles((theme) => ({
//   ...theme.customStyles,
//   label: {
//     ...theme.customStyles.label,
//     "& span": {
//       marginLeft: 6,
//       color: theme.palette.primary.main,
//     },
//   },
//   anchorOriginTopLeftRectangle: {
//     top: 30,
//   },
//   badge: {
//     height: 36,
//     width: 36,
//     borderRadius: 18,
//     border: "3px solid #fff",
//   },
//   badgeRoot: {
//     display: "block",
//     margin: `20px 15px`,
//   },
//   formGroup: {
//     display: "flex",
//     alignItems: "center",
//     "& img": {
//       width: 128,
//       minWidth: 128,
//       maxHeight: 128,
//       minHeight: 128,
//       borderRadius: 10,
//       border: "1.6px solid #DFE8F1",
//       cursor: "pointer",
//       [theme.breakpoints.only("xs")]: {
//         width: 60,
//         minWidth: 60,
//         maxHeight: 60,
//         minHeight: 60,
//       },
//     },
//   },
//   fileFormTitle: {
//     marginLeft: theme.spacing(3),
//     [theme.breakpoints.only("xs")]: { marginLeft: theme.spacing(1) },
//   },
//   countrySelectContainer: {
//     display: "flex",
//     alignItems: "center",
//     width: "100%",
//     position: "relative",
//     "& svg": {
//       cursor: "pointer",
//     },
//     "& img": { width: "30px", height: "20px" },
//   },
//   addItems: {
//     display: "flex",
//     alignItems: "center",
//     margin: `${theme.spacing(2)}px 0px`,
//     [theme.breakpoints.only("xs")]: { flexDirection: "column" },
//     "& img": {
//       cursor: "pointer",
//       width: "100%",
//       borderRadius: 4,
//     },
//     "& input": {
//       margin: `0px ${theme.spacing(1)}px`,
//     },
//     "& button": {
//       width: "30%",
//       backgroundColor: "#4BA4FF",
//       color: "#fff",
//       borderRadius: 10,
//       "&:hover": {
//         // color: "#000",
//         backgroundColor: theme.palette.info.dark,
//       },
//     },
//   },
//   items: {
//     display: "flex",
//     alignItems: "center",
//     justifyContent: "space-between",
//     border: "none",
//     margin: `${theme.spacing(2)}px 0px`,
//     [theme.breakpoints.down("sm")]: { flexDirection: "column" },
//     "& input": {
//       border: "none",
//       "&:focus": {
//         outline: "none",
//       },
//     },
//     [theme.breakpoints.only("xs")]: {
//       flexDirection: "column",
//       "& div": { width: "100%" },
//     },
//   },

//   iconContainer: {
//     display: "flex",
//     alignItems: "center",
//     justifyContent: "space-between",
//     width: "100%",
//     flex: ".3",
//   },

//   itemIcons: {
//     background: "#f4f4f8",
//     borderRadius: 6,
//     alignItems: "center",
//     display: "flex",
//     justifyContent: "center",
//     "& img": {
//       "&:hover": { cursor: "pointer", transform: "scale(1.1)" },
//       transition: `all 200ms ${theme.transitions.easing.easeInOut}`,
//       borderRadius: 6,
//       padding: 11,
//       width: "85%",
//       height: "auto",
//     },
//   },
//   imageUpload: {
//     width: "100%",
//     objectFit: "cover",
//     height: "auto",
//     display: "flex",
//     alignItems: "center",
//     [theme.breakpoints.only("xs")]: { marginBottom: theme.spacing(1) },
//   },
//   postImage: {
//     maxWidth: 60,
//     minWidth: 60,
//     maxHeight: 60,
//     minHeight: 60,
//   },
//   uploadedImage: {
//     maxWidth: 140,
//     objectFit: "cover",
//     height: "auto",
//     "& img": {
//       borderRadius: 10,
//       border: "1.6px solid #DFE8F1",
//       maxWidth: 60,
//       minWidth: 60,
//       maxHeight: 60,
//       minHeight: 60,
//     },
//   },
//   timeContainer: {
//     display: "flex",
//     [theme.breakpoints.down("sm")]: { flexDirection: "column" },
//     "& input": {
//       [theme.breakpoints.up("md")]: { width: "80%" },
//     },
//   },
//   hoursLabelCheckbox: {
//     marginLeft: `${theme.spacing(4)}px !important`,
//     "& span:last-child": {
//       fontSize: "1rem",
//       fontWeight: "bold",
//     },
//   },
//   hourList: {
//     maxHeight: 200,
//     zIndex: 999,
//     width: "100%",
//     position: "absolute",
//     overflowY: "scroll",
//     top: 42,
//     left: 0,
//     "&::-webkit-scrollbar": {
//       width: "0.4em",
//     },
//   },
//   dragDropContainer: {
//     outline: "none",
//     "& img:hover": {
//       transition: `all 200ms ${theme.transitions.easing.easeInOut}`,
//       transform: "scale(1.04)",
//     },
//   },
//   linearRoot: {
//     height: 8,
//     borderRadius: 5,
//   },
//   bar: {
//     borderRadius: 5,
//     backgroundColor: "#1a90ff",
//   },
//   linearProgressBg: {
//     backgroundColor: "#e6e6e6 !important",
//   },
//   inputWithPeso: {
//     display: "flex",
//     alignItems: "center",
//     border: "1.6px solid #d1d3e2",
//     borderRadius: 6,
//     padding: "6.5px 10px",
//     background: "#f4f4f8",
//     margin: `0px 16px 0px 8px`,
//     width: "70%",
//     "& img": {
//       width: 16,
//     },
//     "& input": {
//       padding: "5px",
//       border: "none",
//       fontSize: "1rem",
//       fontWeight: 400,
//       color: "#3c397c",
//       background: "none",
//       "&:focus": {
//         outline: "none",
//       },
//       "&::placeholder": {
//         color: "#3c397c",
//         opacity: "0.5",
//       },
//     },
//   },
//   customDropDown: {
//     display: "flex",
//     alignItems: "center",
//     justifyContent: "space-between",
//     border: "1.6px solid #d1d3e2",
//     borderRadius: 6,
//     padding: "6.5px 10px",
//     background: "#f4f4f8",
//     margin: `${theme.spacing(2)}px 0px`,
//     position: "relative",
//     "& svg": { cursor: "pointer" },
//     "& input": {
//       padding: "5px",
//       border: "none",
//       fontSize: "1rem",
//       fontWeight: 400,
//       color: "#3c397c",
//       background: "none",
//       "&:focus": {
//         outline: "none",
//       },
//       "&::placeholder": {
//         color: "#3c397c",
//         opacity: "0.5",
//       },
//     },
//   },
//   googleSearch: {
//     display: "flex",
//     alignItems: "center",
//     margin: theme.spacing(1),
//     "& span": {
//       "&[data-user-value]": { color: "#000", fontWeight: 600 },
//       "&[data-suggested-value]": { color: "#7F7F7F" },
//     },
//   },
// }));
