import { useEffect, useState, useRef } from "react";
import useOnclickOutside from "react-cool-onclickoutside";
import hours from "../../helpers/hours";
//Material ui
import Paper from "@material-ui/core/Paper";
import Badge from "@material-ui/core/Badge";
import Checkbox from "@material-ui/core/Checkbox";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import useStyles from "./storeHoursStyles";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import IconButton from "@material-ui/core/IconButton";
import Typography from "@material-ui/core/Typography";
import withWidth from "@material-ui/core/withWidth";
import ArrowDownIcon from "@material-ui/icons/ExpandMore";

import WeekHoursInput from "./WeekHoursInput";
import { convertTime12to24 } from "../../helpers/ampmTo24hours";

function TimeInput({
  setInfos,
  infos,
  errorTime,
  setErrorTime,
  errorDayHours,
  setErrorDayHours,
  isErrorDayHours,
  width,
}) {
  const classes = useStyles();
  const [showHours, setShowHours] = useState(false);
  const [openStart, setOpenStart] = useState(false);
  const [openEnd, setOpenEnd] = useState(false);
  const [isOpen, setIsOpen] = useState({
    monday: { openStart: false, openEnd: false, isCheck: false },
    tuesday: { openStart: false, openEnd: false, isCheck: false },
    wednesday: { openStart: false, openEnd: false, isCheck: false },
    thursday: { openStart: false, openEnd: false, isCheck: false },
    friday: { openStart: false, openEnd: false, isCheck: false },
    saturday: { openStart: false, openEnd: false, isCheck: false },
    sunday: { openStart: false, openEnd: false, isCheck: false },
  });
  const paperRef = useRef();
  const ref = useOnclickOutside(() => handleClose());

  useEffect(() => {
    if (errorTime || Object.keys(errorDayHours).length > 0) {
      paperRef.current.scrollIntoView({
        behavior: "smooth",
        block: "center",
        inline: "nearest",
      });
    }
  }, [errorTime, errorDayHours]);

  useEffect(() => {
    if (infos.opening_hours?.monday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        monday: { isCheck: true },
      }));
    }
    if (infos.opening_hours?.tuesday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        tuesday: { isCheck: true },
      }));
    }
    if (infos.opening_hours?.wednesday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        wednesday: { isCheck: true },
      }));
    }
    if (infos.opening_hours?.thursday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        thursday: { isCheck: true },
      }));
    }
    if (infos.opening_hours?.friday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        friday: { isCheck: true },
      }));
    }
    if (infos.opening_hours?.saturday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        saturday: { isCheck: true },
      }));
    }
    if (infos.opening_hours?.sunday?.start_hours) {
      setShowHours(true);
      setIsOpen((prevState) => ({
        ...prevState,
        sunday: { isCheck: true },
      }));
    }
  }, [infos.opening_hours]);

  const handleOpenStart = () => {
    setOpenStart(!openStart);
    if (errorTime) {
      setErrorTime("");
    }
  };

  const handleOpenEnd = () => {
    setOpenEnd(!openEnd);
  };

  const handleClose = () => {
    setOpenEnd(false);
    setOpenStart(false);
  };

  const handleSelectItemStart = (time) => {
    if (time !== infos.store_hours_end) {
      setInfos((prevState) => ({
        ...prevState,
        store_hours_start: time,
      }));
    }
    if (openEnd) {
      setOpenEnd(false);
    } else {
      setOpenStart(false);
    }
  };

  const handleSelectItemEnd = (time) => {
    if (time === infos.store_hours_start) {
      return;
    }
    setInfos((prevState) => ({
      ...prevState,
      store_hours_end: time,
    }));
    setOpenEnd(false);
    setOpenStart(false);
    if (errorTime) {
      setErrorTime("");
    }
  };

  const handleCheckboxChange = () => {
    if (!showHours) {
      setInfos((prevState) => ({
        ...prevState,
        store_hours_start: "",
        store_hours_end: "",
      }));
    }
    setShowHours(!showHours);
    if(showHours){
      setInfos(prevState => ({
        ...prevState,
        opening_hours: {}
      }))
      setIsOpen({
        monday: { openStart: false, openEnd: false, isCheck: false },
        tuesday: { openStart: false, openEnd: false, isCheck: false },
        wednesday: { openStart: false, openEnd: false, isCheck: false },
        thursday: { openStart: false, openEnd: false, isCheck: false },
        friday: { openStart: false, openEnd: false, isCheck: false },
        saturday: { openStart: false, openEnd: false, isCheck: false },
        sunday: { openStart: false, openEnd: false, isCheck: false },
      });
    }
  };
  const isGreaterThanStart = (hour) => {
    if (infos.store_hours_end) {
      if(infos.store_hours_end === hour){
        return true
      }
      if (
        new Date(
          "1/1/1999 " + convertTime12to24(infos.store_hours_end) + ":00"
        ) < new Date("1/1/1999 " + convertTime12to24(hour) + ":00")
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };
  const isGreaterThanEnd = (hour) => {
    if (infos.store_hours_start) {
      if(infos.store_hours_start === hour){
        return true
      }
      if (
        new Date(
          "1/1/1999 " + convertTime12to24(infos.store_hours_start) + ":00"
        ) > new Date("1/1/1999 " + convertTime12to24(hour) + ":00")
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };
  return (
    <Badge
      color="primary"
      badgeContent="4"
      overlap="rectangle"
      anchorOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
      classes={{
        anchorOriginTopLeftRectangle: classes.anchorOriginTopLeftRectangle,
        badge: classes.badge,
        root: classes.badgeRoot,
      }}
    >
      <Paper
        elevation={3}
        className={classes.paperRoot}
        style={{ border: errorTime && !isErrorDayHours ? "1px solid red" : "" }}
        ref={paperRef}
      >
        <label
          className={classes.label}
          style={{ color: showHours ? "rgba(0, 0, 0, 0.54)" : "#000" }}
        >
          Store Hours
          <span>*</span>
        </label>
        <div className={classes.timeContainer}>
          <div>
            <div
              ref={ref}
              className={classes.customDropDown}
              onClick={handleOpenStart}
            >
              <input
                name="store_hours_start"
                placeholder="Opening Hour"
                disabled="disabled"
                value={infos.store_hours_start}
                onChange={(e) => e.preventDefault()}
                style={{
                  color: showHours ? "rgba(0, 0, 0, 0.54)" : "#3c397c",
                  width: "100%",
                }}
              />
              <IconButton
                onClick={handleOpenStart}
                style={{ padding: 0 }}
                disableRipple={showHours}
              >
                <ArrowDownIcon fontSize="small" />
              </IconButton>
              {openStart && !showHours && (
                <Paper square className={classes.hourList} variant="outlined">
                  <List dense>
                    {hours.map((time, i) => (
                      <ListItem
                        selected={time === infos.store_hours_start}
                        onClick={() => handleSelectItemStart(time)}
                        button
                        dense
                        key={i}
                        disabled={isGreaterThanStart(time)}
                      >
                        <ListItemText primary={time} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              )}
            </div>
          </div>
          {width !== "xs" && (
            <span
              style={{
                display: "flex",
                alignItems: "center",
                fontSize: "1rem",
                color: "#3c397c",
                justifyContent: "center",
                margin: "0px 24px",
              }}
            >
              -
            </span>
          )}
          <div>
            <div
              ref={ref}
              className={classes.customDropDown}
              onClick={handleOpenEnd}
            >
              <input
                placeholder="Closing Hour"
                disabled="disabled"
                value={infos.store_hours_end}
                onChange={(e) => e.preventDefault()}
                style={{
                  color: showHours ? "rgba(0, 0, 0, 0.54)" : "#3c397c",
                  width: "100%",
                }}
              />
              <IconButton
                onClick={handleOpenEnd}
                style={{ padding: 0 }}
                disableRipple={showHours}
              >
                <ArrowDownIcon fontSize="small" />
              </IconButton>
              {openEnd && !showHours && (
                <Paper square className={classes.hourList} variant="outlined">
                  <List dense>
                    {hours.map((time, i) => (
                      <ListItem
                        selected={time === infos.store_hours_end}
                        onClick={() => handleSelectItemEnd(time)}
                        button
                        dense
                        key={i}
                        disabled={isGreaterThanEnd(time)}
                      >
                        <ListItemText primary={time} />
                      </ListItem>
                    ))}
                  </List>
                </Paper>
              )}
            </div>
          </div>
          <FormControlLabel
            className={classes.hoursLabelCheckbox}
            control={
              <Checkbox
                color="secondary"
                checked={showHours}
                onClick={handleCheckboxChange}
              />
            }
            label="Input your own hours"
          />
        </div>
        {errorTime && !isErrorDayHours && (
          <Typography variant="body2" color="error">
            {errorTime}
          </Typography>
        )}

        <WeekHoursInput
          showHours={showHours}
          setInfos={setInfos}
          infos={infos}
          isOpen={isOpen}
          setIsOpen={setIsOpen}
          errorTime={errorTime}
          setErrorTime={setErrorTime}
          errorDayHours={errorDayHours}
          setErrorDayHours={setErrorDayHours}
          isErrorDayHours={isErrorDayHours}
          setShowHours={setShowHours}
        />
      </Paper>
    </Badge>
  );
}

export default withWidth()(TimeInput);
