import { makeStyles } from "@material-ui/core/styles";

export default makeStyles((theme) => ({
  ...theme.customStyles,
  label: {
    ...theme.customStyles.label,
    "& span": {
      marginLeft: 6,
      color: theme.palette.primary.main,
    },
  },
  anchorOriginTopLeftRectangle: {
    top: 30,
  },
  badge: {
    height: 36,
    width: 36,
    borderRadius: 18,
    border: "3px solid #fff",
  },
  badgeRoot: {
    display: "block",
    margin: `20px 15px`,
  },
  customDropDown: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    border: "1.6px solid #d1d3e2",
    borderRadius: 6,
    padding: "6.5px 10px",
    background: "#f4f4f8",
    margin: `${theme.spacing(2)}px 0px`,
    position: "relative",
    "& svg": { cursor: "pointer" },
    "& input": {
      padding: "5px",
      border: "none",
      fontSize: "1rem",
      fontWeight: 400,
      color: "#3c397c",
      background: "none",
      "&:focus": {
        outline: "none",
      },
      "&::placeholder": {
        color: "#3c397c",
        opacity: "0.5",
      },
    },
  },
  timeContainer: {
    display: "flex",
    [theme.breakpoints.down("sm")]: { flexDirection: "column" },
    "& input": {
      [theme.breakpoints.up("md")]: { width: "80%" },
    },
  },
  hoursLabelCheckbox: {
    marginLeft: `${theme.spacing(4)}px !important`,
    [theme.breakpoints.only("xs")]: { marginLeft: "0px !important" },
    "& span:last-child": {
      fontSize: "1rem",
      fontWeight: "bold",
    },
  },
  hourList: {
    maxHeight: 200,
    zIndex: 999,
    width: "100%",
    position: "absolute",
    overflowY: "scroll",
    top: 42,
    left: 0,
    "&::-webkit-scrollbar": {
      width: "0.4em",
    },
  },
}));
