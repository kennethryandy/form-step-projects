import { useEffect, useState } from "react";
import useOnclickOutside from "react-cool-onclickoutside";
import hours from "../../helpers/hours";
//Muit
import withWidth from "@material-ui/core/withWidth";
import Checkbox from "@material-ui/core/Checkbox";
import Collapse from "@material-ui/core/Collapse";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Divider from "@material-ui/core/Divider";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import { convertTime12to24 } from "../../helpers/ampmTo24hours";

const useStyles = makeStyles((theme) => ({
  wrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexWrap: "wrap",
    [theme.breakpoints.up("sm")]: { margin: `${theme.spacing(4)}px 0px` },
    [theme.breakpoints.only("xs")]: { justifyContent: "center" },
  },
  hourContainer: {
    position: "relative",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: 110,
    height: 55,
    border: "1px solid",
    borderRadius: 6,
    cursor: "pointer",
  },
  hourList: {
    maxHeight: 190,
    zIndex: 999,
    width: "100%",
    position: "absolute",
    overflowY: "scroll",
    top: 55,
    "&::-webkit-scrollbar": {
      width: "0.4em",
    },
  },
  listPadding: {
    paddingRight: 0,
  },
  day: {
    display: "flex",
    alignItems: "center",
    [theme.breakpoints.only("xs")]: { marginRight: "auto" },
  },
  timeWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    width: 260,
    [theme.breakpoints.only("xs")]: { margin: `${theme.spacing(2)}px 0px` },
  },
  gridContainer: {
    marginLeft: 16,
    [theme.breakpoints.only("xs")]: { marginLeft: 0 },
  },
}));

const WeekHoursInput = ({
  showHours,
  setShowHours,
  setInfos,
  infos,
  isOpen,
  setIsOpen,
  setErrorTime,
  errorTime,
  errorDayHours,
  setErrorDayHours,
  isErrorDayHours,
  width,
}) => {
  const classes = useStyles();
  const [selectedDay, setSelectedDay] = useState("");
  const ref = useOnclickOutside(() => handleClose());
  useEffect(() => {
    if (isErrorDayHours) {
      setShowHours(true);
    }
    return () => setShowHours(false);
  }, [isErrorDayHours, setShowHours]);

  const openStartDay = (day) => {
    setSelectedDay(day);
    setIsOpen((prevState) => ({
      ...prevState,
      [day]: {
        ...prevState[day],
        openStart: prevState[day].isCheck ? !prevState[day].openStart : false,
      },
    }));
  };

  const openEndDay = (day) => {
    setSelectedDay(day);
    setIsOpen((prevState) => ({
      ...prevState,
      [day]: {
        ...prevState[day],
        openEnd: prevState[day].isCheck ? !prevState[day].openEnd : false,
      },
    }));
  };

  const handleCheckChange = (day) => {
    if (errorDayHours[`${day}Start`]) {
      setErrorTime("");
      setErrorDayHours((prevState) => ({
        ...prevState,
        [`${day}Start`]: false,
      }));
    }
    if (errorDayHours[`${day}End`]) {
      setErrorTime("");
      setErrorDayHours((prevState) => ({
        ...prevState,
        [`${day}End`]: false,
      }));
    }
    setInfos((prevState) => ({
      ...prevState,
      opening_hours: {
        ...prevState.opening_hours,
        [day]: {
          start_hours: "",
          end_hours: "",
        },
      },
    }));

    setIsOpen((prevState) => ({
      ...prevState,
      [day]: {
        openStart: false,
        openEnd: false,
        isCheck: !prevState[day].isCheck,
      },
    }));
  };

  const handleClose = () => {
    if (selectedDay) {
      setIsOpen((prevState) => ({
        ...prevState,
        [selectedDay]: {
          ...prevState[selectedDay],
          openStart: false,
          openEnd: false,
        },
      }));
    } else {
      return;
    }
  };
  return (
    <Collapse in={showHours}>
      <Grid container spacing={width === "xs" ? 3 : 10}>
        <Grid item md={5} xs={12} className={classes.gridContainer}>
          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.monday?.isCheck}
                onClick={() => handleCheckChange("monday")}
              />
              <Typography variant="body1" color="secondary">
                Monday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.mondayStart ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.mondayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("monday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.monday?.start_hours}
                </Typography>
                {isOpen.monday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.mondayStart}
                    errorType="mondayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setIsOpen={setIsOpen}
                    setInfos={setInfos}
                    day="monday"
                    type="openStart"
                    i="start_hours"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.mondayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.mondayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("monday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.monday?.end_hours}
                </Typography>
                {isOpen.monday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.mondayEnd}
                    errorType="mondayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    type="openEnd"
                    i="end_hours"
                    day="monday"
                  />
                )}
              </div>
            </div>
          </div>

          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.tuesday?.isCheck}
                onClick={() => handleCheckChange("tuesday")}
              />
              <Typography variant="body1" color="secondary">
                Tuesday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.tuesdayStart ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.tuesdayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("tuesday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.tuesday?.start_hours}
                </Typography>
                {isOpen.tuesday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.tuesdayStart}
                    errorType="tuesdayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    type="openStart"
                    i="start_hours"
                    day="tuesday"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.tuesdayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.tuesdayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("tuesday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.tuesday?.end_hours}
                </Typography>
                {isOpen.tuesday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.tuesdayEnd}
                    errorType="tuesdayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="tuesday"
                    type="openEnd"
                    i="end_hours"
                  />
                )}
              </div>
            </div>
          </div>

          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.wednesday?.isCheck}
                onClick={() => handleCheckChange("wednesday")}
              />
              <Typography variant="body1" color="secondary">
                Wednesday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.wednesdayStart
                    ? "red"
                    : "#d1d3e2",
                  backgroundColor: errorDayHours?.wednesdayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("wednesday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.wednesday?.start_hours}
                </Typography>
                {isOpen.wednesday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.wednesdayStart}
                    errorType="wednesdayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="wednesday"
                    type="openStart"
                    i="start_hours"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.wednesdayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.wednesdayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("wednesday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.wednesday?.end_hours}
                </Typography>
                {isOpen.wednesday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.wednesdayEnd}
                    errorType="wednesdayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="wednesday"
                    type="openEnd"
                    i="end_hours"
                  />
                )}
              </div>
            </div>
          </div>

          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.thursday?.isCheck}
                onClick={() => handleCheckChange("thursday")}
              />
              <Typography variant="body1" color="secondary">
                Thursday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.thursdayStart ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.thursdayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("thursday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.thursday?.start_hours}
                </Typography>
                {isOpen.thursday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.thursdayStart}
                    errorType="thursdayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="thursday"
                    type="openStart"
                    i="start_hours"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.thursdayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.thursdayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("thursday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.thursday?.end_hours}
                </Typography>
                {isOpen.thursday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.thursdayEnd}
                    errorType="thursdayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="thursday"
                    type="openEnd"
                    i="end_hours"
                  />
                )}
              </div>
            </div>
          </div>
        </Grid>
        <Grid item md={5} xs={12}>
          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.friday?.isCheck}
                onClick={() => handleCheckChange("friday")}
              />
              <Typography variant="body1" color="secondary">
                Friday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.fridayStart ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.fridayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("friday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.friday?.start_hours}
                </Typography>
                {isOpen.friday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.fridayStart}
                    errorType="fridayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="friday"
                    type="openStart"
                    i="start_hours"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.fridayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.fridayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("friday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.friday?.end_hours}
                </Typography>
                {isOpen.friday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.fridayEnd}
                    errorType="fridayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="friday"
                    type="openEnd"
                    i="end_hours"
                  />
                )}
              </div>
            </div>
          </div>

          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.saturday?.isCheck}
                onClick={() => handleCheckChange("saturday")}
              />
              <Typography variant="body1" color="secondary">
                Saturday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  marginRight: 16,
                  borderColor: errorDayHours?.saturdayStart ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.saturdayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("saturday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.saturday?.start_hours}
                </Typography>
                {isOpen.saturday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.saturdayStart}
                    errorType="saturdayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="saturday"
                    type="openStart"
                    i="start_hours"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.saturdayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.saturdayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("saturday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.saturday?.end_hours}
                </Typography>
                {isOpen.saturday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.saturdayEnd}
                    errorType="saturdayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="saturday"
                    type="openEnd"
                    i="end_hours"
                  />
                )}
              </div>
            </div>
          </div>

          <div className={classes.wrapper}>
            <div className={classes.day}>
              <Checkbox
                color="secondary"
                checked={isOpen.sunday?.isCheck}
                onClick={() => handleCheckChange("sunday")}
              />
              <Typography variant="body1" color="secondary">
                Sunday
              </Typography>
            </div>
            <div className={classes.timeWrapper}>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.sundayStart ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.sundayStart
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openStartDay("sunday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Opening Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.sunday?.start_hours}
                </Typography>
                {isOpen.sunday?.openStart && (
                  <HourList
                    infos={infos}
                    j="end_hours"
                    errorDayHours={errorDayHours?.sundayStart}
                    errorType="sundayStart"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="sunday"
                    type="openStart"
                    i="start_hours"
                  />
                )}
              </div>
              <div
                className={classes.hourContainer}
                style={{
                  borderColor: errorDayHours?.sundayEnd ? "red" : "#d1d3e2",
                  backgroundColor: errorDayHours?.sundayEnd
                    ? "rgba(244,68,79,0.2)"
                    : "#f4f4f8",
                }}
                onClick={() => openEndDay("sunday")}
                ref={ref}
              >
                <Typography
                  style={{ cursor: "pointer" }}
                  variant="body2"
                  color="textSecondary"
                >
                  Closing Hour
                </Typography>
                <Typography variant="body2">
                  {infos.opening_hours.sunday?.end_hours}
                </Typography>
                {isOpen.sunday?.openEnd && (
                  <HourList
                    infos={infos}
                    j="start_hours"
                    errorDayHours={errorDayHours?.sundayEnd}
                    errorType="sundayEnd"
                    setErrorDayHours={setErrorDayHours}
                    setErrorTime={setErrorTime}
                    setInfos={setInfos}
                    setIsOpen={setIsOpen}
                    day="sunday"
                    type="openEnd"
                    i="end_hours"
                  />
                )}
              </div>
            </div>
          </div>
        </Grid>
      </Grid>
      {isErrorDayHours && (
        <Typography variant="body2" color="error">
          {errorTime}
        </Typography>
      )}
    </Collapse>
  );
};

const HourList = ({
  setInfos,
  type,
  setIsOpen,
  day,
  i,
  j,
  setErrorTime,
  errorType,
  setErrorDayHours,
  errorDayHours,
  infos,
}) => {
  const classes = useStyles();

  const handleSelectTime = (hour) => {
    setIsOpen((prevState) => ({
      ...prevState,
      [day]: { isCheck: true, [type]: false },
    }));
    if (errorDayHours) {
      setErrorTime("");
      setErrorDayHours((prevState) => ({ ...prevState, [errorType]: false }));
    }
    setInfos((prevState) => ({
      ...prevState,
      opening_hours: {
        ...prevState.opening_hours,
        [day]: {
          ...prevState.opening_hours[day],
          [i]: hour,
        },
      },
    }));
  };
  const isGreaterThan = (hour) => {
    if(infos?.opening_hours[day][j] === hour){
      return true
    }
    if (infos?.opening_hours[day][j]) {
      if (
        i === "end_hours" &&
        new Date(
          "1/1/1999 " + convertTime12to24(infos?.opening_hours[day][j]) + ":00"
        ) > new Date("1/1/1999 " + convertTime12to24(hour) + ":00")
      ) {
        return true;
      } else if (
        i === "start_hours" &&
        new Date(
          "1/1/1999 " + convertTime12to24(infos?.opening_hours[day][j]) + ":00"
        ) < new Date("1/1/1999 " + convertTime12to24(hour) + ":00")
      ) {
        return true;
      } else {
        return false;
      }
    }
    return false;
  };

  return (
    <Paper elevation={3} className={classes.hourList}>
      <List dense>
        {hours.map((hour, i) => (
            <div key={i}>
              <ListItem
                classes={{ gutters: classes.listPadding }}
                button
                onClick={() => handleSelectTime(hour)}
                disabled={isGreaterThan(hour)}
              >
                <ListItemText primary={hour} />
              </ListItem>
              <Divider />
            </div>
          )
        )}
      </List>
    </Paper>
  );
};

export default withWidth()(WeekHoursInput);
