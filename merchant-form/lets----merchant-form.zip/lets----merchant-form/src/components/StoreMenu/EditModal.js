import { forwardRef } from "react";
import pesoIcon from "../../assets/icons/peso_icon.svg";
//Mui
import Button from "@material-ui/core/Button";
import Paper from "@material-ui/core/Paper";
import Dialog from "@material-ui/core/Dialog";
import DialogTitle from "@material-ui/core/DialogTitle";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import IconButton from "@material-ui/core/IconButton";
import Slide from "@material-ui/core/Slide";
//Mui icon
import CloseIcon from "@material-ui/icons/Close";
import DeleteForeverIcon from "@material-ui/icons/DeleteForever";
import DoneIcon from "@material-ui/icons/Done";

const EditModal = ({
  classes,
  open,
  setOpen,
  handlePreventLetterE,
  setFocus,
  focus,
  editInput,
  handleChange,
  handleRemoveItem,
  handleSave,
}) => {
  const handleClose = () => {
    setOpen(false);
  };
  const handleSaveEdit = () => {
    handleSave();
    setOpen(false);
  };
  const handleDeleteItem = () => {
    handleRemoveItem(editInput);
    setOpen(false);
  };
  return (
    <Dialog
      open={open}
      onClose={handleClose}
      classes={{ root: classes.rootDialog, paper: classes.paperAddRoot }}
      maxWidth="xs"
      scroll="paper"
      TransitionComponent={Transition}
    >
      <IconButton style={{ alignSelf: "flex-end" }} onClick={handleClose}>
        <CloseIcon />
      </IconButton>
      <DialogTitle className={classes.title}>Edit Item</DialogTitle>
      <DialogContent>
        <DialogContentText>
          <Paper
            elevation={2}
            style={{ padding: 8, borderRadius: 10, marginBottom: 24 }}
          >
            <label className={classes.label}>Product Name</label>
            <input
              type="text"
              className="form-control"
              placeholder="Product Name"
              name="item_name"
              value={editInput.item_name}
              onChange={handleChange}
              //   onKeyPress={handleKeyPress}
              style={{ padding: "8px 20px" }}
            />
          </Paper>
          <Paper elevation={2} style={{ padding: 8, borderRadius: 10 }}>
            <label className={classes.label}>Price</label>
            <div
              className={classes.inputWithPesoAdd}
              style={{ borderColor: focus ? " #4ba4ff" : "" }}
            >
              <img src={pesoIcon} alt="peso" />
              <input
                placeholder="Price"
                name="price"
                value={editInput.price}
                onChange={handleChange}
                type="number"
                onKeyDown={handlePreventLetterE}
                onFocus={() => setFocus(true)}
                onBlur={() => setFocus(false)}
              />
            </div>
          </Paper>
        </DialogContentText>
      </DialogContent>
      <DialogActions className={classes.btns}>
        <Button
          size="large"
          variant="contained"
          color="secondary"
          onClick={handleSaveEdit}
          fullWidth
          endIcon={<DoneIcon />}
        >
          Save
        </Button>
        <Button
          size="large"
          variant="contained"
          color="primary"
          onClick={handleDeleteItem}
          fullWidth
          endIcon={<DeleteForeverIcon />}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

const Transition = forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default EditModal;
