import { useState } from "react";
import validationSchema, { validateDailyHours } from "../config/validation";
import { addProducts, sendMerchantForm } from "../api";
import { useHistory } from "react-router-dom";
//Material ui
import Button from "@material-ui/core/Button";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import withWidth from "@material-ui/core/withWidth";
import CircularProgress from "@material-ui/core/CircularProgress";
import { makeStyles } from "@material-ui/core/styles";
//Components
import FileForm from "./Forms/FileForm/FileForm";
import InputForm from "./Forms/InputForm/InputForm";
import TextForm from "./Forms/TextForm/TextForm";
import Map from "./GoogleMap/Map";
import TimeInput from "./StoreHours/TimeInput";
import StoreMenu from "./StoreMenu/StoreMenu";
import SelectForm from "./Forms/SelectForm/SelectForm";
import PhoneInput from "./Forms/PhoneInput/PhoneInput";
import { Formik } from "formik";
const useStyles = makeStyles((theme) => ({
  btn: {
    margin: `${theme.spacing(1)}px ${theme.spacing(2)}px ${
      theme.spacing(5) * 2
    }px ${theme.spacing(2)}px`,
    width: "16%",
    [theme.breakpoints.only("sm")]: { width: "30%" },
    [theme.breakpoints.only("xs")]: {
      width: "100%",
      margin: "0px 0px 24px 0px",
    },
    fontWeight: "bold",
    backgroundColor: "#FFC001",
    "&:hover": {
      backgroundColor: "#ffcc33",
    },
  },
  mapGrid: {
    width: "100%",
    margin: "auto",
  },
  title: {
    [theme.breakpoints.only("xs")]: { marginTop: theme.spacing(5) },
    padding: "20px 15px",
    "& h3": { fontWeight: "bold" },
    "& p": {
      margin: `${theme.spacing(1)}px 0px`,
      letterSpacing: "0.1em",
    },
  },
}));

function FormsContainer(props) {
  const classes = useStyles();
  const history = useHistory();
  const [errorCategory, setErrorCategory] = useState("");
  const [errorLocation, setErrorLocation] = useState("");
  const [errorTime, setErrorTime] = useState("");
  const [isErrorDayHours, setIsErrorDayHours] = useState(false);
  const [errorDayHours, setErrorDayHours] = useState({});
  const [isValidEmail, setIsValidEmail] = useState(false);
  return (
    <div style={{ overflowX: "hidden" }}>
      <div className={classes.title}>
        <Typography variant="h3">Business Details</Typography>
        <Typography variant="body1" color="textSecondary">
          Enter your business details to get started
        </Typography>
      </div>
      <Grid container justify="space-around" spacing={5}>
        <Grid item className={classes.mapGrid}>
          <Map
            setInfos={props.setInfos}
            errorLocation={errorLocation}
            setErrorLocation={setErrorLocation}
          />
        </Grid>
      </Grid>
      <Formik
        initialValues={{
          store_name: "",
          email_address: "",
          phone_number: "",
          landline_number: "",
          store_description: "",
        }}
        validationSchema={validationSchema}
        onSubmit={async (data) => {
          const { isError, errorDayHours } = validateDailyHours(
            props.infos.opening_hours
          );
          if (!isValidEmail) return;
          if (!props.infos.location_full_address || !props.infos.place_id) {
            return setErrorLocation("Please select your location on the map.");
          }
          if (!props.infos.category.trim()) {
            setErrorCategory("Please select category for your store.");
          }

          if (
            isError &&
            (!props.infos.store_hours_start || !props.infos.store_hours_end)
          ) {
            if (isError && Object.keys(errorDayHours).length !== 0) {
              setIsErrorDayHours(isError);
              setErrorDayHours(errorDayHours);
              return setErrorTime("Please complete the store hours.");
            }
            setIsErrorDayHours(false);
            return setErrorTime("Please enter your store hours.");
          }
          let newData = {
            ...props.infos,
            ...data,
          };
          const res = await sendMerchantForm(newData);
          if (res.success) {
            if (props.products.length > 0) {
              const productResponse = await addProducts(
                props.products,
                res.token
              );
              if (productResponse) {
                props.setIsSuccess(true);
                history.push("/success");
              } else {
                return;
              }
            } else {
              props.setIsSuccess(true);
              history.push("/success");
            }
          } else {
            return;
          }
        }}
      >
        {({
          values,
          handleChange,
          handleSubmit,
          handleBlur,
          errors,
          isSubmitting,
        }) => {
          return (
            <form onSubmit={handleSubmit}>
              <Grid
                container
                justify="space-around"
                alignItems="center"
                spacing={props.width === "sm" ? 0 : 5}
              >
                <Grid item sm={6} xs={12}>
                  <FileForm setInfos={props.setInfos} />
                </Grid>
                <Grid item sm={6} xs={12}>
                  <InputForm
                    num="3"
                    text="Store Name"
                    placeholder="Store Name"
                    name="store_name"
                    handleChange={handleChange}
                    value={values.store_name}
                    handleBlur={handleBlur}
                    errors={errors}
                    infos={props.infos}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={props.width === "sm" ? 0 : 5}>
                <Grid item sm={12} xs={12}>
                  <TimeInput
                    setInfos={props.setInfos}
                    infos={props.infos}
                    errorTime={errorTime}
                    setErrorTime={setErrorTime}
                    errorDayHours={errorDayHours}
                    setErrorDayHours={setErrorDayHours}
                    isErrorDayHours={isErrorDayHours}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={props.width === "sm" ? 0 : 5}>
                <Grid item xs={12}>
                  <SelectForm
                    infos={props.infos}
                    setInfos={props.setInfos}
                    errorCategory={errorCategory}
                    setErrorCategory={setErrorCategory}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={props.width === "sm" ? 0 : 5}>
                <Grid item xs={12}>
                  <InputForm
                    num="6"
                    text="Email Address"
                    placeholder="Enter a valid email address"
                    name="email_address"
                    handleChange={handleChange}
                    value={values.email_address}
                    handleBlur={handleBlur}
                    type="email"
                    isValidEmail={isValidEmail}
                    setIsValidEmail={setIsValidEmail}
                  />
                </Grid>
              </Grid>
              <Grid
                container
                justify="space-around"
                spacing={props.width === "sm" ? 0 : 5}
              >
                <Grid item sm={6} xs={12}>
                  <PhoneInput
                    handleChange={handleChange}
                    value={values.phone_number}
                    handleBlur={handleBlur}
                    name="phone_number"
                    errors={errors}
                    infos={props.infos}
                  />
                </Grid>
                <Grid item sm={6} xs={12}>
                  <InputForm
                    num="8"
                    text="Landline Number"
                    placeholder="(021)-210-1234"
                    name="landline_number"
                    value={values.landline_number}
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    infos={props.infos}
                  />
                </Grid>
              </Grid>

              <Grid container spacing={props.width === "sm" ? 0 : 5}>
                <Grid item xs={12}>
                  <TextForm
                    text="Store Description"
                    handleChange={handleChange}
                    handleBlur={handleBlur}
                    value={values.store_description}
                    name="store_description"
                    errors={errors}
                  />
                </Grid>
              </Grid>
              <Grid container spacing={props.width === "sm" ? 0 : 5}>
                <Grid xs={12} item>
                  <StoreMenu
                    products={props.products}
                    setProducts={props.setProducts}
                  />
                </Grid>
              </Grid>
              <Button
                variant="contained"
                size="large"
                className={classes.btn}
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? <CircularProgress /> : "Register"}
              </Button>
            </form>
          );
        }}
      </Formik>
    </div>
  );
}

export default withWidth()(FormsContainer);
