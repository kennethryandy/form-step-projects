import { lazy, Suspense } from "react";
import successLogo from "../assets/images/success_logo.png";
import succesSd from "../assets/images/success_sd.jpg";
import { Link } from "react-router-dom";
//Material ui
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import { makeStyles } from "@material-ui/core/styles";
const Img = lazy(() => import("../components/Image/Img"));

const useStyles = makeStyles((theme) => ({
  bannerText: {
    maxWidth: 440,
    textAlign: "justify",
    [theme.breakpoints.down("sm")]: {
      margin: "50px 0px",
    },
    "& h1": { fontWeight: "bold" },
    "& h2": { margin: `${theme.spacing(1)}px 0px` },
    "& p": { lineHeight: 2.2, fontSize: "1.2rem" },
    "& button": {
      marginTop: theme.spacing(2),
      fontWeight: 700,
      borderRadius: 9,
      padding: "10px 24px",
      backgroundColor: "#FFC001",
      "&:hover": {
        backgroundColor: "#ffcc33",
      },
    },
  },
  gridItem: {
    display: "flex",
    alignItems: "center",
  },
  girdContainer: {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
}));

function SuccessPage() {
  const classes = useStyles();
  return (
    <Grid container className={classes.girdContainer} spacing={5}>
      <Grid item sm={6} className={classes.gridItem}>
        <div className={classes.bannerText}>
          <Typography variant="h1" color="primary">
            Sent
          </Typography>
          <Typography variant="h2">Sucessfully</Typography>
          <Typography variant="body1" color="textSecondary">
            <strong>NOTE:</strong> Due to limited operations, we may take 1-2
            weeks to reach out to you after your application.
          </Typography>
          <Button variant="contained" size="large" color="secondary">
            <Link style={{ textDecoration: "none", color: "#000" }} to="/">
              Send another form
            </Link>
          </Button>
        </div>
      </Grid>
      <Grid item sm={6}>
        <div>
          <Suspense fallback={<img src={succesSd} alt="" width="640" />}>
            <Img src={successLogo} alt="" />
          </Suspense>
        </div>
      </Grid>
    </Grid>
  );
}

export default SuccessPage;
