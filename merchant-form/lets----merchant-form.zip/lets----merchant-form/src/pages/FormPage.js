import { useState } from "react";

import Banner from "../components/Banner";
import FormsContainer from "../components/FormsContainer";

function FormPage({ setIsSuccess }) {
  const [infos, setInfos] = useState({
    store_name: "",
    phone_number: "",
    landline_number: "",
    location_full_address: "",
    lat: "",
    lng: "",
    store_hours_start: "",
    store_hours_end: "",
    place_id: "",
    opening_hours: {},
    // category: [],
    category: ""
  });
  const [products, setProducts] = useState([]);

  return (
    <>
      <Banner />
      <FormsContainer
        setInfos={setInfos}
        infos={infos}
        products={products}
        setProducts={setProducts}
        setIsSuccess={setIsSuccess}
      />
    </>
  );
}

export default FormPage;
