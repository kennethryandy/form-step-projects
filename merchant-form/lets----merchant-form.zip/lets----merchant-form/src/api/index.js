import axios from "axios";
import { convertTime12to24 } from "../helpers/ampmTo24hours";
const URL = "API_URL";

export const validateCred = async (params) => {
  return await axios.post(URL + "/validate-cred", params);
};

export const sendMerchantForm = async (data) => {
  let opening_hours = {};
  let store_logo = {};

  if (data.store_logo_file_id) {
    store_logo = {
      store_logo_file_id: data.store_logo_file_id,
    };
  }
  if (data.opening_hours.monday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      monday_store_hours_start: convertTime12to24(
        data.opening_hours?.monday?.start_hours
      ),
    };
  }
  if (data.opening_hours.tuesday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      tuesday_store_hours_start: convertTime12to24(
        data.opening_hours?.tuesday?.start_hours
      ),
    };
  }
  if (data.opening_hours.wednesday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      wednesday_store_hours_start: convertTime12to24(
        data.opening_hours?.wednesday?.start_hours
      ),
    };
  }
  if (data.opening_hours.thursday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      thursday_store_hours_start: convertTime12to24(
        data.opening_hours?.thursday?.start_hours
      ),
    };
  }
  if (data.opening_hours.friday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      friday_store_hours_start: convertTime12to24(
        data.opening_hours?.friday?.start_hours
      ),
    };
  }
  if (data.opening_hours.saturday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      saturday_store_hours_start: convertTime12to24(
        data.opening_hours?.saturday?.start_hours
      ),
    };
  }
  if (data.opening_hours.sunday?.start_hours) {
    opening_hours = {
      ...opening_hours,
      sunday_store_hours_start: convertTime12to24(
        data.opening_hours?.sunday?.start_hours
      ),
    };
  }
  if (data.opening_hours.monday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      monday_store_hours_end: convertTime12to24(
        data.opening_hours?.monday?.end_hours
      ),
    };
  }
  if (data.opening_hours.tuesday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      tuesday_store_hours_end: convertTime12to24(
        data.opening_hours?.tuesday?.end_hours
      ),
    };
  }
  if (data.opening_hours.wednesday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      wednesday_store_hours_end: convertTime12to24(
        data.opening_hours?.wednesday?.end_hours
      ),
    };
  }
  if (data.opening_hours.thursday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      thursday_store_hours_end: convertTime12to24(
        data.opening_hours?.thursday?.end_hours
      ),
    };
  }
  if (data.opening_hours.friday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      friday_store_hours_end: convertTime12to24(
        data.opening_hours?.friday?.end_hours
      ),
    };
  }
  if (data.opening_hours.saturday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      saturday_store_hours_end: convertTime12to24(
        data.opening_hours?.saturday?.end_hours
      ),
    };
  }
  if (data.opening_hours.sunday?.end_hours) {
    opening_hours = {
      ...opening_hours,
      sunday_store_hours_end: convertTime12to24(
        data.opening_hours?.sunday?.end_hours
      ),
    };
  }

  const phone_number = data.phone_number.replace(/[^0-9]+/g, "");
  // const category = data.category.join();

  const newData = {
    ...opening_hours,
    ...store_logo,
    store_hours_start: data.store_hours_start
      ? convertTime12to24(data.store_hours_start)
      : "12:00",
    store_hours_end: data.store_hours_end
      ? convertTime12to24(data.store_hours_end)
      : "24:00",
    store_name: data.store_name,
    email: data.email_address,
    phone_number,
    location_full_address: data.location_full_address,
    category: data.category,
    place_id: data.place_id,
    landline_number: data.landline_number,
    store_description: data.store_description,
    lat: data.lat,
    lng: data.lng,
  };
  try {
    const res = await axios.post(`${URL}/subscription-form`, newData);
    return res.data;
  } catch (err) {
    console.error(err);
  }
};

export const addProducts = async (products, token) => {
  const success = await Promise.all(
    products.map(async (product) => {
      const res = await axios.post(
        `${URL}/product/add`,
        { ...product,product_price: product.product_price.replace(/\D/g,'') , details: null },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return res.data.success;
    })
  );
  return success[0];
};

export const uploadLogo = async (image, setProgress) => {
  const res = axios.post(`${URL}/upload-file`, image, {
    onUploadProgress: (event) => {
      const { loaded, total } = event;
      let percent = Math.floor((loaded * 100) / total);
      if (percent < 100) {
        setProgress(percent);
      }
    },
  });
  return res;
};

export const uploadProductLogo = async (image) => {
  const res = await axios.post(`${URL}/upload-file`, image);
  return res;
};
