import { createMuiTheme, responsiveFontSizes } from "@material-ui/core/styles";

let theme = createMuiTheme({
  palette: {
    primary: {
      main: "#F4444F",
      light: "#f66972",
      dark: "#aa2f37",
    },
    secondary: {
      main: "#4BA4FF",
      light: "#6fb6ff",
      dark: "#3472b2",
    },
  },
  fontFamily: [
    // "San Francisco",
    "-apple-system",
    "BlinkMacSystemFont",
    '"Segoe UI"',
    "Roboto",
    '"Helvetica Neue"',
    "Arial",
    "sans-serif",
    '"Apple Color Emoji"',
    '"Segoe UI Emoji"',
    '"Segoe UI Symbol"',
  ].join(","),
  customStyles: {
    dFlex: {
      display: "flex",
    },
    alignCenter: {
      display: "flex",
      alignItems: "center",
    },
    paperRoot: {
      padding: "32px 24px",
      borderRadius: 6,
    },
    label: {
      fontSize: "1rem",
      fontWeight: "bold",
    },
  },
});
theme = responsiveFontSizes(theme);

export default theme;
