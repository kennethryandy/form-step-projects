const variables = {
  googleApiKey: "",
  dev_googleApiKey: "",
};

export default variables;
