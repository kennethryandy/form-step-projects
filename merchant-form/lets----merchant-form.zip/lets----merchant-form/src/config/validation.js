import * as yup from "yup";
const schema = yup.object({
  store_name: yup
    .string()
    .required("Please enter a store name.")
    .min(4, "Store name must be at least 4 characters long."),
  email_address: yup
    .string()
    .required("Please enter an email address.")
    .email("Email adress is invalid."),
  phone_number: yup
    .string()
    .required("Please enter a phone number.")
    .test(
      "",
      "Phone number must start with number 9",
      (value) => value?.toString()[0] === "9"
    )
    .test("", "Phone number must be 10 digits long.", (value) => {
      let newValue = value?.toString()?.replace(/[^0-9]+/g, "");
      return newValue?.length >= 10;
    }),
  landline_number: yup
    .string()
    .test("", "Landline number number must be 10 digits long.", (value) => {
      if (value?.toString()?.length > 0) {
        let newValue = value?.toString()?.replace(/[^0-9]+/g, "");
        return newValue?.length >= 10;
      } else {
        return true;
      }
    }),
  // category: yup
  //   .array()
  //   .of(yup.string().required("Please select category for your store.")),
  store_description: yup
    .string()
    .max(255, "Store description must be no longer than 255 characters."),
});

export const validateDailyHours = (opening_hours) => {
  const {
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
    sunday,
  } = opening_hours;
  let errorDayHours = {};
  let isError = false;
  //monday
  if (!monday?.start_hours && monday?.end_hours) {
    errorDayHours = { ...errorDayHours, mondayStart: true };
    isError = true;
  }
  if (monday?.start_hours && !monday?.end_hours) {
    errorDayHours = { ...errorDayHours, mondayEnd: true };
    isError = true;
  }
  //tuesday
  if (!tuesday?.start_hours && tuesday?.end_hours) {
    errorDayHours = { ...errorDayHours, tuesdayStart: true };
    isError = true;
  }
  if (tuesday?.start_hours && !tuesday?.end_hours) {
    errorDayHours = { ...errorDayHours, tuesdayEnd: true };
    isError = true;
  }
  //wednesday
  if (!wednesday?.start_hours && wednesday?.end_hours) {
    errorDayHours = {
      ...errorDayHours,
      wednesdayStart: true,
    };
    isError = true;
  }
  if (wednesday?.start_hours && !wednesday?.end_hours) {
    errorDayHours = { ...errorDayHours, wednesdayEnd: true };
    isError = true;
  }
  //thursday
  if (!thursday?.start_hours && thursday?.end_hours) {
    errorDayHours = {
      ...errorDayHours,
      thursdayStart: true,
    };
    isError = true;
  }
  if (thursday?.start_hours && !thursday?.end_hours) {
    errorDayHours = { ...errorDayHours, thursdayEnd: true };
    isError = true;
  }
  //friday
  if (!friday?.start_hours && friday?.end_hours) {
    errorDayHours = { ...errorDayHours, fridayStart: true };
    isError = true;
  }
  if (friday?.start_hours && !friday?.end_hours) {
    errorDayHours = { ...errorDayHours, fridayEnd: true };
    isError = true;
  }
  //saturday
  if (!saturday?.start_hours && saturday?.end_hours) {
    errorDayHours = {
      ...errorDayHours,
      saturdayStart: true,
    };
    isError = true;
  }
  if (saturday?.start_hours && !saturday?.end_hours) {
    errorDayHours = { ...errorDayHours, saturdayEnd: true };
    isError = true;
  }
  //sunday
  if (!sunday?.start_hours && sunday?.end_hours) {
    errorDayHours = { ...errorDayHours, sundayStart: true };
    isError = true;
  }
  if (sunday?.start_hours && !sunday?.end_hours) {
    errorDayHours = { ...errorDayHours, sundayEnd: true };
    isError = true;
  }
  if (
    !monday?.start_hours &&
    !monday?.end_hours &&
    !tuesday?.start_hours &&
    !tuesday?.end_hours &&
    !wednesday?.start_hours &&
    !wednesday?.end_hours &&
    !thursday?.start_hours &&
    !thursday?.end_hours &&
    !friday?.start_hours &&
    !friday?.end_hours &&
    !saturday?.start_hours &&
    !saturday?.end_hours &&
    !sunday?.start_hours &&
    !sunday?.end_hours
  ) {
    isError = true;
  }
  return { isError, errorDayHours };
};

export default schema;
